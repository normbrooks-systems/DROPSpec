' ExportGrip.bas — "Export as .grip" for LibreOffice
'
' Exports the current document to a temporary PDF using LibreOffice's own PDF
' filter, then runs grip-write on it to produce a DROPSpec .grip container
' next to the document.
'
' Install: Tools > Macros > Edit Macros, put this in a module under
' My Macros > Standard, then bind ExportGrip to a menu item, toolbar button
' or keyboard shortcut via Tools > Customize.
'
' The PDF export path is used deliberately rather than the print path: it is
' deterministic, unaffected by the selected printer, and preserves the
' document's page size, which becomes the container's MediaBox.

Option Explicit

' ---- settings ------------------------------------------------------------
' If grip-write is not on the PATH LibreOffice sees (Flatpak and Snap builds
' notably do not inherit your shell PATH), put the absolute path here.
Const GRIP_WRITE = "grip-write"
Const PROFILE    = "ddp01-mono"
Const HALFTONE   = "floyd-steinberg"
' --------------------------------------------------------------------------


Sub ExportGrip
    Dim oDoc As Object
    Dim sDocUrl As String, sPdfUrl As String, sGripPath As String
    Dim aArgs(1) As New com.sun.star.beans.PropertyValue
    Dim sCmd As String, sLog As String
    Dim nStatus As Integer

    oDoc = ThisComponent
    If IsNull(oDoc) Then
        MsgBox "No document is open.", 48, "Export as .grip"
        Exit Sub
    End If

    sDocUrl = oDoc.getURL()
    If sDocUrl = "" Then
        MsgBox "Save the document first — the .grip is written next to it.", _
               48, "Export as .grip"
        Exit Sub
    End If

    sPdfUrl   = Left(sDocUrl, Len(sDocUrl) - Len(GetExtension(sDocUrl))) & "grip.pdf"
    sGripPath = ConvertFromURL(Left(sDocUrl, Len(sDocUrl) - Len(GetExtension(sDocUrl))) & "grip")

    ' 1. Export to PDF with LibreOffice's own filter.
    aArgs(0).Name  = "FilterName"
    aArgs(0).Value = PdfFilterFor(oDoc)
    aArgs(1).Name  = "Overwrite"
    aArgs(1).Value = True
    oDoc.storeToURL(sPdfUrl, aArgs())

    ' 2. Hand the PDF to the RIP.
    sCmd = Quote(GRIP_WRITE) & " " & Quote(ConvertFromURL(sPdfUrl)) & _
           " -o " & Quote(sGripPath) & _
           " --profile " & PROFILE & _
           " --halftone " & HALFTONE & _
           " --job-name " & Quote(FileNameOutOfPath(ConvertFromURL(sDocUrl)))

    nStatus = RunAndWait(sCmd, sLog)

    ' 3. Clean up the intermediate PDF.
    If FileExists(sPdfUrl) Then Kill(sPdfUrl)

    If nStatus <> 0 Then
        MsgBox "grip-write failed (exit " & nStatus & ")." & Chr(10) & Chr(10) & _
               sLog & Chr(10) & "Command was:" & Chr(10) & sCmd, 16, "Export as .grip"
    ElseIf Not FileExists(ConvertToURL(sGripPath)) Then
        MsgBox "grip-write reported success but wrote nothing to" & Chr(10) & _
               sGripPath, 16, "Export as .grip"
    Else
        MsgBox "Wrote" & Chr(10) & sGripPath & Chr(10) & Chr(10) & _
               "Check it with:  grip-validate " & sGripPath & Chr(10) & _
               "Proof it with:  grip-render " & sGripPath & " -o proof.pdf", _
               64, "Export as .grip"
    End If
End Sub


' The PDF export filter name is per document type.
Function PdfFilterFor(oDoc As Object) As String
    If oDoc.supportsService("com.sun.star.sheet.SpreadsheetDocument") Then
        PdfFilterFor = "calc_pdf_Export"
    ElseIf oDoc.supportsService("com.sun.star.presentation.PresentationDocument") Then
        PdfFilterFor = "impress_pdf_Export"
    ElseIf oDoc.supportsService("com.sun.star.drawing.DrawingDocument") Then
        PdfFilterFor = "draw_pdf_Export"
    Else
        PdfFilterFor = "writer_pdf_Export"
    End If
End Function


Function GetExtension(sUrl As String) As String
    Dim n As Integer
    n = InStrRev(sUrl, ".")
    If n = 0 Then
        GetExtension = ""
    Else
        GetExtension = Mid(sUrl, n + 1)
    End If
End Function


Function Quote(s As String) As String
    Quote = """" & s & """"
End Function


' Shell() with bSync = True waits, but does not hand back an exit status, so
' the status and the output are routed through temporary files.
Function RunAndWait(sCmd As String, ByRef sLog As String) As Integer
    Dim sDir As String, sStatus As String, sOut As String
    Dim iFile As Integer, sLine As String

    sDir    = ConvertFromURL(CreateUnoService( _
                  "com.sun.star.util.PathSettings").Temp)
    sStatus = sDir & "/grip-export.status"
    sOut    = sDir & "/grip-export.log"

    Shell("/bin/sh -c " & Quote(sCmd & " > " & Quote(sOut) & " 2>&1; echo $? > " & _
          Quote(sStatus)), 1, "", True)

    RunAndWait = -1
    sLog = ""

    If FileExists(ConvertToURL(sStatus)) Then
        iFile = FreeFile
        Open ConvertToURL(sStatus) For Input As #iFile
        Line Input #iFile, sLine
        Close #iFile
        RunAndWait = CInt(Trim(sLine))
        Kill(ConvertToURL(sStatus))
    End If

    If FileExists(ConvertToURL(sOut)) Then
        iFile = FreeFile
        Open ConvertToURL(sOut) For Input As #iFile
        Do While Not EOF(iFile)
            Line Input #iFile, sLine
            sLog = sLog & sLine & Chr(10)
        Loop
        Close #iFile
        Kill(ConvertToURL(sOut))
    End If
End Function
