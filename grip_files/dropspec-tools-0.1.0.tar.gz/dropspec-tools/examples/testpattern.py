#!/usr/bin/env python3
"""Calibration fixtures, written straight through the container API.

These bypass the raster path entirely: the patterns are defined in nozzle
space, which is where they are read back from. That makes them independent of
the RIP, so a bad print points at the machine rather than at the screening.

    python examples/testpattern.py nozzles  -o nozzle-check.grip
    python examples/testpattern.py stitch   -o stitch.grip
    python examples/testpattern.py register -o register.grip

Loosely: G5 (nozzle health), G3 (stitch verification), G2 (bidirectional).
"""

from __future__ import annotations

import argparse
import datetime as dt

import numpy as np

from dropspec.container import GripWriter
from dropspec.model import DIR_XNEG, DIR_XPOS, PassRow, Swath, mm_to_dots
from dropspec.profile import DDP01_MONO


def _blank(profile, columns):
    return np.zeros((columns, profile.nozzles_per_pen), dtype=bool)


def nozzles(profile, columns, pen, pass_index):
    """Every nozzle fires a short dash, staggered so each is individually read."""
    buf = _blank(profile, columns)
    dash = max(2, columns // 400)
    step = max(dash * 2, columns // (profile.nozzles_per_pen + 4))
    for n in range(profile.nozzles_per_pen):
        start = 20 + n * step
        if start + dash >= columns:
            break
        buf[start : start + dash, n] = True
    return buf


def stitch(profile, columns, pen, pass_index):
    """Solid bars broken by clear gaps, so a band boundary shows as a step."""
    buf = _blank(profile, columns)
    bar = max(4, int(mm_to_dots(2.0, profile.dpi_scan)))
    gap = bar * 2
    x = 40
    while x + bar < columns:
        buf[x : x + bar, :] = True
        x += bar + gap
    # Clear the outermost nozzle of each pen so the overlap zone is visible.
    buf[:, 0] = False
    buf[:, -1] = False
    return buf


def register(profile, columns, pen, pass_index):
    """Vertical rules at a fixed pitch.

    Scan-offset error appears at 2x between directions, so a bidirectional
    job prints these as doubled lines exactly when the trigger point differs
    between XPOS and XNEG.
    """
    buf = _blank(profile, columns)
    pitch = max(8, int(mm_to_dots(5.0, profile.dpi_scan)))
    width = max(2, int(mm_to_dots(0.2, profile.dpi_scan)))
    for x in range(pitch, columns - pitch, pitch):
        buf[x : x + width, :] = True
    return buf


PATTERNS = {"nozzles": nozzles, "stitch": stitch, "register": register}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pattern", choices=sorted(PATTERNS))
    ap.add_argument("-o", "--output")
    ap.add_argument("--passes", type=int, default=4)
    ap.add_argument("--width", type=float, default=215.9, help="media width, mm")
    ap.add_argument("--height", type=float, default=279.4, help="media height, mm")
    args = ap.parse_args()

    profile = DDP01_MONO
    make = PATTERNS[args.pattern]
    out = args.output or f"{args.pattern}.grip"

    columns = int(round(mm_to_dots(args.width + 2 * profile.lead_mm, profile.dpi_scan)))
    manifest = profile.manifest(args.width, args.height)
    manifest.job_name = f"{args.pattern} test pattern"
    manifest.created = dt.datetime.now(dt.timezone.utc).replace(
        microsecond=0).isoformat().replace("+00:00", "Z")
    manifest.halftone = "none"

    droplets = {p: 0 for p in range(profile.pens)}
    with GripWriter(out) as writer:
        for k in range(args.passes):
            direction = DIR_XPOS if k % 2 == 0 else DIR_XNEG
            origin_y = round(
                args.height - (k + 1) * profile.gang_height_mm, 4
            )
            swaths = []
            for pen in range(profile.pens):
                # Patterns are authored in page order (low x first). File
                # space puts line 0 at the far end on XNEG, so a fixture that
                # must land in the same place both ways is reversed here.
                bits = make(profile, columns, pen, k + 1)
                if direction == DIR_XNEG:
                    bits = bits[::-1]
                droplets[pen] += int(np.count_nonzero(bits))
                swaths.append(
                    Swath(page=1, index=k + 1, pen=pen,
                          rows=profile.nozzles_per_pen, columns=columns,
                          dir=direction, bits=bits)
                )
            writer.add_pass(
                PassRow(1, k + 1, round(-profile.lead_mm, 4), origin_y, direction),
                swaths,
            )
        for spec in manifest.pen_specs:
            spec.planned_droplets = droplets[spec.index]
            spec.planned_consumption = round(
                spec.planned_droplets * spec.drop_volume_pl * 1e-9, 12
            )
        manifest.pages = 1
        writer.close(manifest)

    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
