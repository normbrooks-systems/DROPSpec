import numpy as np
import pytest

from dropspec import ppp
from dropspec.model import GripFormatError, Swath


def make(rows=7, columns=5, seed=0):
    rng = np.random.default_rng(seed)
    bits = rng.random((columns, rows)) > 0.5
    return Swath(page=3, index=12, pen=1, rows=rows, columns=columns,
                 dir="XNEG", bits=bits)


def test_round_trip_is_exact():
    sw = make()
    back = ppp.loads(ppp.dumps(sw))
    assert np.array_equal(back.bits, sw.bits)
    assert (back.page, back.index, back.pen, back.dir) == (3, 12, 1, "XNEG")
    assert (back.rows, back.columns) == (sw.rows, sw.columns)


def test_line_length_is_rows_plus_one_and_terminated():
    sw = make(rows=7, columns=3)
    lines = ppp.dumps(sw).decode().split("\n")
    assert lines[0].startswith("# ROWS:7 COLUMNS:3 PAGE:003 PASS:012 PEN:01")
    for line in lines[1:-1]:
        assert len(line) == 8
        assert line.endswith(";")
        assert set(line[:-1]) <= {"8", "."}


def test_crlf_is_tolerated():
    data = ppp.dumps(make()).replace(b"\n", b"\r\n")
    assert np.array_equal(ppp.loads(data).bits, make().bits)


def test_corrupt_glyph_reports_a_line_number():
    rows, columns = 7, 5
    data = bytearray(ppp.dumps(make(rows=rows, columns=columns)))
    header_end = data.index(b"\n")
    stride = rows + 2  # nozzles + ';' + '\n'
    data[header_end + 1 + stride + 2] = ord("X")  # line 3, character 2
    with pytest.raises(GripFormatError) as exc:
        ppp.loads(bytes(data), "bad.ppp")
    assert "line 3" in str(exc.value)
    assert "character 2" in str(exc.value)


def test_short_line_reports_a_line_number():
    text = ppp.dumps(make(rows=7, columns=4)).decode().split("\n")
    text[2] = text[2][:-2] + ";"
    with pytest.raises(GripFormatError) as exc:
        ppp.loads("\n".join(text).encode(), "short.ppp")
    assert "line 3" in str(exc.value)


def test_header_must_be_strict_key_colon_value():
    with pytest.raises(GripFormatError):
        ppp.parse_header("# ROWS: 300 COLUMNS:5100")
    with pytest.raises(GripFormatError):
        ppp.parse_header("ROWS:300")


def test_missing_header_field_is_a_fault():
    with pytest.raises(GripFormatError) as exc:
        ppp.parse_header("# ROWS:8 COLUMNS:2 PAGE:001 PASS:001 PEN:00")
    assert "ACTIVE" in str(exc.value)


def test_space_as_inactive_survives_a_round_trip():
    """Space is the documented alternate INACTIVE glyph, but the header is
    space-delimited, so it has to be escaped to be declarable at all."""
    sw = make()
    sw.inactive = " "
    data = ppp.dumps(sw)
    assert b"INACTIVE:SP " in data
    back = ppp.loads(data)
    assert np.array_equal(back.bits, sw.bits)
    assert back.inactive == " "
