import numpy as np
import pytest

from dropspec.raster import PageRaster


@pytest.fixture
def tiny_profile():
    from dropspec.profile import MachineProfile

    # A deliberately small press: 4 pens of 8 nozzles, 2-nozzle overlap.
    return MachineProfile(
        name="tiny",
        pens=4,
        nozzles_per_pen=8,
        dpi_media=100,
        dpi_scan=100,
        overlap_nozzles=2,
        colorants=["black"] * 4,
        lead_mm=1.0,
    )


@pytest.fixture
def tiny_page():
    rng = np.random.default_rng(1234)
    rows, cols = 60, 40
    cov = rng.random((rows, cols)).astype(np.float32)
    width_mm = cols * 25.4 / 100
    height_mm = rows * 25.4 / 100
    return PageRaster(cov, width_mm, height_mm)
