"""Mutation tests: break one thing, check the validator names that thing."""

import re
import shutil
import zipfile

import pytest

from dropspec.rip import RipOptions, rip
from dropspec.validate import FAULT, validate


@pytest.fixture
def good(tmp_path, tiny_profile, tiny_page):
    out = str(tmp_path / "good.grip")
    rip([tiny_page], tiny_profile, out, RipOptions(halftone="bayer"))
    return out


def mutate(src, dst, drop=(), replace=None):
    """Rewrite a .grip, dropping members and rewriting others."""
    replace = replace or {}
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(
        dst, "w", zipfile.ZIP_DEFLATED
    ) as zout:
        for item in zin.infolist():
            if item.filename in drop:
                continue
            data = zin.read(item.filename)
            if item.filename in replace:
                data = replace[item.filename](data)
            zout.writestr(item.filename, data)
    return dst


def set_key(key, value):
    """Rewrite `key = ...` in an ini member."""
    def rewrite(data):
        return re.sub(
            rf"(?m)^{key} = .*$".encode(), f"{key} = {value}".encode(), data, count=1
        )
    return rewrite


def checks(report):
    return {f.check for f in report.findings if f.level == FAULT}


def test_a_good_container_passes(good):
    report = validate(good)
    assert report.ok, [str(f) for f in report.findings]
    assert report.checked_swaths > 0


def test_roll_profile_is_refused_before_anything_else(good, tmp_path):
    bad = mutate(
        good, str(tmp_path / "roll.grip"),
        replace={"manifest.ini": set_key("profile", "roll")},
    )
    report = validate(bad)
    assert not report.ok
    assert checks(report) == {"1 profile"}, "check 1 must short-circuit"


def test_corrupt_swath_line_is_reported_with_a_line_number(good, tmp_path):
    def corrupt(data):
        head, _, body = data.partition(b"\n")
        lines = body.split(b"\n")
        lines[2] = lines[2][:-2] + b"Q;"
        return head + b"\n" + b"\n".join(lines)

    bad = mutate(good, str(tmp_path / "corrupt.grip"),
                 replace={"rip/001_001_00.ppp": corrupt})
    report = validate(bad)
    assert "2 swath body" in checks(report)
    assert any("line 4" in f.message for f in report.faults)


def test_header_disagreeing_with_filename_is_a_fault(good, tmp_path):
    bad = mutate(
        good, str(tmp_path / "misfiled.grip"),
        replace={"rip/001_001_00.ppp": lambda d: d.replace(b"PEN:00", b"PEN:01", 1)},
    )
    assert "3 filename" in checks(validate(bad))


def test_dir_disagreeing_with_passes_csv_is_a_fault(good, tmp_path):
    bad = mutate(
        good, str(tmp_path / "dir.grip"),
        replace={"rip/001_001_00.ppp": lambda d: d.replace(b"DIR:XPOS", b"DIR:XNEG", 1)},
    )
    report = validate(bad)
    assert "4 dir" in checks(report)
    assert any("authoritative" in f.message for f in report.faults)


def test_rows_disagreeing_with_the_head_is_a_fault(good, tmp_path):
    bad = mutate(
        good, str(tmp_path / "rows.grip"),
        replace={"manifest.ini": set_key("nozzles_per_pen", 9)},
    )
    report = validate(bad)
    assert "5 rows" in checks(report)


def test_passes_total_disagreeing_with_the_row_count_is_a_fault(good, tmp_path):
    bad = mutate(
        good, str(tmp_path / "total.grip"),
        replace={"manifest.ini": set_key("passes_total", 9)},
    )
    report = validate(bad)
    assert "6 passes_total" in checks(report)


def test_missing_pen_file_is_a_fault(good, tmp_path):
    bad = mutate(good, str(tmp_path / "missing.grip"), drop=("rip/001_002_02.ppp",))
    report = validate(bad)
    assert "7 pen set" in checks(report)
    assert any("missing pen(s) [2]" in f.message for f in report.faults)


def test_orphan_swath_is_a_fault(good, tmp_path):
    orphan = str(tmp_path / "orphan.grip")
    shutil.copy(good, orphan)
    with zipfile.ZipFile(good) as z:
        payload = z.read("rip/001_001_00.ppp").replace(b"PASS:001", b"PASS:099")
    with zipfile.ZipFile(orphan, "a", zipfile.ZIP_DEFLATED) as z:
        z.writestr("rip/001_099_00.ppp", payload)
    report = validate(orphan)
    assert "7 pen set" in checks(report)


def test_planned_droplets_mismatch_is_a_warning_not_a_fault(good, tmp_path):
    bad = mutate(
        good, str(tmp_path / "prov.grip"),
        replace={"manifest.ini": set_key("planned_droplets", 1)},
    )
    report = validate(bad)
    assert report.ok, "provenance is informative, not conformance"
    assert any("provenance" == f.check for f in report.warnings)


def test_not_a_zip(tmp_path):
    path = tmp_path / "nope.grip"
    path.write_bytes(b"this is not a zip")
    assert not validate(str(path)).ok
