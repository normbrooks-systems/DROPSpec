import re

from dropspec.container import GripReader
from dropspec.rip import RipOptions, rip


def gcode_for(tmp_path, profile, page):
    out = str(tmp_path / "g.grip")
    rip([page], profile, out, RipOptions(halftone="bayer"))
    with GripReader(out) as r:
        return r.gcode, r.manifest, r.rows


def test_cold_start_loads_then_arms(tmp_path, tiny_profile, tiny_page):
    text, m, _ = gcode_for(tmp_path, tiny_profile, tiny_page)
    lines = [l.strip() for l in text.splitlines() if l.strip()
             and not l.strip().startswith(";")]
    q1 = [i for i, l in enumerate(lines) if l.startswith("Q1")]
    t = [i for i, l in enumerate(lines) if re.fullmatch(r"T\d\d", l)]
    assert len(q1) == m.pens, "Q1 is cold start only, once per pen"
    assert len(t) == m.pens
    assert max(q1) < min(t), "load the go buffer before arming"


def test_steady_state_is_q3_then_q2_and_never_q1(tmp_path, tiny_profile, tiny_page):
    text, m, rows = gcode_for(tmp_path, tiny_profile, tiny_page)
    assert text.count("\nQ1") == m.pens
    # One stage and one verify per pen for every pass after the first.
    assert len(re.findall(r"^Q2\d\d", text, re.M)) == m.pens * (len(rows) - 1)
    assert len(re.findall(r"^Q3\d\d", text, re.M)) == m.pens * (len(rows) - 1)


def test_job_ends_discarding_both_buffers(tmp_path, tiny_profile, tiny_page):
    text, m, _ = gcode_for(tmp_path, tiny_profile, tiny_page)
    tail = text.rsplit("end of job", 1)[1]
    assert len(re.findall(r"^Q4\d\d", tail, re.M)) == m.pens


def test_file_override_is_present_and_greppable(tmp_path, tiny_profile, tiny_page):
    text, _, _ = gcode_for(tmp_path, tiny_profile, tiny_page)
    assert "Q100 FILE=001_001_00.ppp" in text
    # Klipper takes the whole first token as the command name, so the space
    # before FILE= is load-bearing.
    for line in text.splitlines():
        if line.startswith("Q") and "FILE" in line:
            assert re.fullmatch(r"Q\d{3} FILE=\d{3}_\d{3}_\d{2}\.ppp", line)


def test_sweep_direction_matches_passes_csv(tmp_path, tiny_profile, tiny_page):
    text, m, rows = gcode_for(tmp_path, tiny_profile, tiny_page)
    sweeps = re.findall(r"^G1 X(-?[\d.]+) F\d+\n G1 X(-?[\d.]+)", text, re.M)
    moves = re.findall(r"^G1 X(-?[\d.]+) F(\d+)$", text, re.M)
    # Pairs of (travel to start, print to end).
    assert len(moves) == 2 * len(rows)
    for i, row in enumerate(rows):
        start = float(moves[2 * i][0])
        end = float(moves[2 * i + 1][0])
        if row.dir == "XPOS":
            assert end > start
        else:
            assert end < start


def test_media_advance_matches_the_origin_delta(tmp_path, tiny_profile, tiny_page):
    text, _, rows = gcode_for(tmp_path, tiny_profile, tiny_page)
    advances = [float(v) for v in re.findall(r"^G1 Y(-?[\d.]+) F\d+$", text, re.M)]
    expected = [
        round(a.origin_y - b.origin_y, 4) for a, b in zip(rows, rows[1:])
    ]
    assert advances == expected
