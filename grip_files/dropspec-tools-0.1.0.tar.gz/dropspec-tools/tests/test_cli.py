"""End to end through the console entry points."""

import numpy as np
import pytest
from PIL import Image

from dropspec.cli import info as info_cli
from dropspec.cli import render as render_cli
from dropspec.cli import validate as validate_cli
from dropspec.cli import write as write_cli


@pytest.fixture
def source_png(tmp_path):
    rng = np.random.default_rng(7)
    art = np.full((400, 300), 255, np.uint8)
    art[50:150, 40:260] = 0
    art[200:380, 40:260] = (rng.random((180, 220)) * 255).astype(np.uint8)
    path = tmp_path / "art.png"
    Image.fromarray(art, "L").save(path)
    return str(path)


def test_write_validate_render_png(tmp_path, source_png, capsys):
    grip = str(tmp_path / "job.grip")
    assert write_cli.main([source_png, "-o", grip, "--page-size", "a5",
                           "--dpi-scan", "150", "--dpi-media", "150", "-q"]) == 0
    assert validate_cli.main([grip, "-q"]) == 0

    png = str(tmp_path / "proof.png")
    assert render_cli.main([grip, "-o", png, "-q", "--max-dimension", "600"]) == 0
    assert Image.open(png).size[0] <= 600

    assert info_cli.main([grip, "--passes"]) == 0
    out = capsys.readouterr().out
    assert "profile sheet" in out and "XPOS" in out


def test_render_pdf_is_a_readable_pdf(tmp_path, source_png):
    grip = str(tmp_path / "job.grip")
    write_cli.main([source_png, "-o", grip, "--page-size", "a5",
                    "--dpi-scan", "150", "--dpi-media", "150", "-q"])
    pdf = str(tmp_path / "proof.pdf")
    assert render_cli.main([grip, "-o", pdf, "-q"]) == 0

    data = open(pdf, "rb").read()
    assert data.startswith(b"%PDF-1.7")
    assert data.rstrip().endswith(b"%%EOF")
    assert b"/ImageMask true" in data
    assert b"/BM /Multiply" in data

    pdfium = pytest.importorskip("pypdfium2")
    doc = pdfium.PdfDocument(pdf)
    assert len(doc) == 1
    page = doc[0]
    # A5 is 148 x 210 mm; MediaBox is the media extent, in points.
    assert page.get_width() == pytest.approx(148 / 25.4 * 72, abs=0.5)
    assert page.get_height() == pytest.approx(210 / 25.4 * 72, abs=0.5)
    rendered = np.asarray(page.render(scale=0.5).to_pil().convert("L"))
    assert rendered.min() < 60, "the proof should actually have ink on it"


def test_bad_input_fails_cleanly(tmp_path, capsys):
    assert write_cli.main([str(tmp_path / "nope.pdf"), "-q"]) == 2
    assert "no such file" in capsys.readouterr().err


def test_validate_exit_status_reports_failure(tmp_path):
    path = tmp_path / "broken.grip"
    path.write_bytes(b"not a zip at all")
    assert validate_cli.main([str(path), "-q"]) == 1
