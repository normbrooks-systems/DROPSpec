import pytest

from dropspec.model import (
    GripOverflowError,
    MAX_PAGES,
    parse_swath_filename,
    swath_filename,
)


def test_padding_is_three_three_two():
    assert swath_filename(1, 1, 0) == "001_001_00.ppp"
    assert swath_filename(999, 999, 99) == "999_999_99.ppp"


def test_lexical_sort_matches_print_order():
    names = [swath_filename(1, p, n) for p in (1, 2, 10, 100) for n in range(3)]
    assert names == sorted(names)


@pytest.mark.parametrize("args", [(1000, 1, 0), (1, 1000, 0), (0, 1, 0), (1, 0, 0)])
def test_overflow_is_a_hard_fault(args):
    with pytest.raises(GripOverflowError):
        swath_filename(*args)


def test_round_trip():
    assert parse_swath_filename("rip/012_003_02.ppp") == (12, 3, 2)


@pytest.mark.parametrize("name", ["1_1_0.ppp", "001_001_0.ppp", "001_001_00.txt"])
def test_bad_names_rejected(name):
    from dropspec.model import GripFormatError

    with pytest.raises(GripFormatError):
        parse_swath_filename(name)
