"""The round trip that matters: what the RIP wrote is what the renderer sees."""

import numpy as np
import pytest

from dropspec import halftone
from dropspec.container import GripReader
from dropspec.model import DIR_XNEG, DIR_XPOS, GripOverflowError
from dropspec.render import compose_page
from dropspec.rip import RipOptions, band_owner_map, plan_page, rip


@pytest.fixture
def ripped(tmp_path, tiny_profile, tiny_page):
    out = str(tmp_path / "job.grip")
    rip([tiny_page], tiny_profile, out, RipOptions(job_name="t", halftone="bayer"))
    return out


def test_render_reproduces_the_screened_page_exactly(ripped, tiny_page):
    expected = halftone.screen(tiny_page.coverage, "bayer")
    with GripReader(ripped) as r:
        proof = compose_page(r, 1)
    union = np.zeros_like(expected)
    for plane in proof.planes.values():
        union |= plane
    assert np.array_equal(union, expected)


def test_every_dot_is_fired_by_exactly_one_pen(ripped):
    with GripReader(ripped) as r:
        proof = compose_page(r, 1)
    stacked = sum(p.astype(np.uint8) for p in proof.planes.values())
    assert stacked.max() <= 1


def test_direction_alternates_and_passes_descend(ripped):
    with GripReader(ripped) as r:
        rows = r.rows_for_page(1)
    assert [x.dir for x in rows] == [
        DIR_XPOS if i % 2 == 0 else DIR_XNEG for i in range(len(rows))
    ]
    ys = [x.origin_y for x in rows]
    assert ys == sorted(ys, reverse=True)


def test_xneg_reverses_line_order_and_nothing_else(tiny_profile):
    """One dot, two directions: same page position, mirrored file position."""
    from dropspec.rip import build_swaths, plan_page

    page_rows, page_cols = tiny_profile.gang_rows, 40
    lead = 4
    dot_row, dot_col = 3, 11
    page_bits = np.zeros((page_rows, page_cols), dtype=bool)
    page_bits[dot_row, dot_col] = True
    owner = band_owner_map(tiny_profile, page_cols)

    planned = plan_page(tiny_profile, 1, page_rows, 100.0, 1.0)[0]
    forward = build_swaths(tiny_profile, planned, page_bits, owner, lead)
    reverse = build_swaths(
        tiny_profile, planned.__class__(**{**planned.__dict__, "dir": DIR_XNEG}),
        page_bits, owner, lead,
    )

    pen = int(owner[dot_row, dot_col])
    fwd = np.asarray(forward[pen].bits)
    rev = np.asarray(reverse[pen].bits)
    columns = forward[pen].columns

    (line,), (char,) = np.nonzero(fwd)[0], np.nonzero(fwd)[1]
    assert line == lead + dot_col
    assert np.array_equal(rev, fwd[::-1])
    assert np.nonzero(rev)[0][0] == columns - 1 - line
    # The nozzle index is untouched: only line order depends on direction.
    assert np.nonzero(rev)[1][0] == char


def test_lead_columns_are_clear_and_counted(ripped, tiny_profile, tiny_page):
    with GripReader(ripped) as reader:
        sw = reader.swath(1, 1, 0)
        page_cols = int(round(reader.manifest.page_width
                              * reader.manifest.dpi_scan / 25.4))
    lead = int(round(tiny_profile.lead_mm * tiny_profile.dpi_scan / 25.4))
    assert sw.columns == page_cols + 2 * lead
    bits = np.asarray(sw.bits)
    assert not bits[:lead].any() and not bits[-lead:].any()


def test_swath_bottom_may_fall_off_the_page_and_is_clipped(ripped):
    with GripReader(ripped) as reader:
        rows = reader.rows_for_page(1)
        proof = compose_page(reader, 1)
    assert rows[-1].origin_y < 0, "last pass should overhang the media"
    assert proof.rows == 60  # clipped to the media extent, not faulted


def test_band_owner_map_covers_every_row_once(tiny_profile):
    owner = band_owner_map(tiny_profile, 40)
    assert owner.shape == (tiny_profile.gang_rows, 40)
    assert set(np.unique(owner)) == set(range(tiny_profile.pens))


def test_overlap_zone_is_shared_by_both_neighbours(tiny_profile):
    owner = band_owner_map(tiny_profile, 400)
    start = tiny_profile.pen_top_row(1)
    zone = owner[start : start + tiny_profile.overlap_nozzles]
    assert set(np.unique(zone)) == {0, 1}, "a stitch should be a ramp, not a butt joint"


def test_no_feather_gives_a_hard_boundary(tiny_profile):
    owner = band_owner_map(tiny_profile, 400, feather=False)
    start = tiny_profile.pen_top_row(1)
    zone = owner[start : start + tiny_profile.overlap_nozzles]
    assert set(np.unique(zone)) == {1}


def test_pass_overflow_refuses_rather_than_widening(tiny_profile):
    with pytest.raises(GripOverflowError):
        plan_page(tiny_profile, 1, page_rows=10_000_000, page_height_mm=1e6,
                  lead_mm=1.0)


def test_page_overflow_refuses(tiny_profile):
    with pytest.raises(GripOverflowError):
        plan_page(tiny_profile, 1000, page_rows=10, page_height_mm=10.0, lead_mm=1.0)


def test_cmyk_pass_planning_is_refused_not_guessed():
    from dropspec.profile import DDP01_CMYK

    with pytest.raises(NotImplementedError):
        plan_page(DDP01_CMYK, 1, 600, 100.0, 3.0)


def test_planned_consumption_is_auditable(ripped):
    with GripReader(ripped) as reader:
        for spec in reader.manifest.pen_specs:
            expected = spec.planned_droplets * spec.drop_volume_pl * 1e-9
            assert abs(spec.planned_consumption - expected) < 1e-6
