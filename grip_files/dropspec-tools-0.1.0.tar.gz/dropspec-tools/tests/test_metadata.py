import pytest

from dropspec import manifest_io, passes_io
from dropspec.model import GripFormatError, Manifest, PassRow, PenSpec


def test_manifest_round_trip():
    m = Manifest(
        job_name="a job", created="2026-08-18T00:00:00Z", pages=2,
        passes_total=12, pens=2, page_width=210.0, page_height=297.0,
        pen_specs=[
            PenSpec(0, "cyan", "#009EE0", 0.0, 12.7, 1234, 0.000037),
            PenSpec(1, "uv_615", None, 0.1, 0.0, 5678, 0.00017),
        ],
    )
    back = manifest_io.loads(manifest_io.dumps(m))
    assert back.job_name == "a job"
    assert back.pens == 2
    assert back.pen(0).colorant == "cyan"
    assert back.pen(0).srgb == "#009EE0"
    assert back.pen(1).srgb is None  # a 615 nm fluorescent has no honest sRGB
    assert back.pen(1).planned_droplets == 5678
    assert back.page_height == 297.0


def test_version_is_first_key():
    text = manifest_io.dumps(Manifest())
    body = text.split("[grip]\n", 1)[1]
    assert body.splitlines()[0].startswith("version = ")


def test_passes_round_trip_and_unpadded():
    rows = [
        PassRow(1, 1, 12.7, 266.7, "XPOS"),
        PassRow(1, 2, 12.7, 215.9, "XNEG"),
        PassRow(12, 100, -3.0, 0.0, "XPOS"),
    ]
    text = passes_io.dumps(rows)
    assert text.splitlines()[1] == "1,1,12.7,266.7,XPOS"
    assert passes_io.loads(text) == rows


def test_header_row_is_required():
    with pytest.raises(GripFormatError):
        passes_io.loads("page,pass,x,y,dir\n1,1,0,0,XPOS\n")


def test_duplicate_key_is_a_fault():
    text = passes_io.HEADER + "\n1,1,0,0,XPOS\n1,1,0,0,XNEG\n"
    with pytest.raises(GripFormatError) as exc:
        passes_io.loads(text)
    assert "duplicate" in str(exc.value)


def test_bad_direction_is_a_fault():
    with pytest.raises(GripFormatError):
        passes_io.loads(passes_io.HEADER + "\n1,1,0,0,FORWARD\n")
