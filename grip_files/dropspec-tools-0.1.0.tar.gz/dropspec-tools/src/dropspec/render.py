"""Reader side: `.grip` in, a proof out.

Render a `.grip` to PDF and if the PDF looks right, the file is right —
before a drop of ink.  Proofing the press without the press.

**The PDF render is a proof, not a conformance artifact.**  It consumes
`[pen.nn] colorant` and `srgb`, which are informative, to choose fill
colours; a PDF that looks wrong in *colour* is not a spec violation.  What it
proves is geometry: that every swath lands where `passes.csv` says it does.

The renderer's full conditional logic is **reverse line order on `XNEG`**.
Everything else is unconditional.  A renderer that ignored `dir` entirely
would still place every swath correctly and only get internal column order
wrong — a visible, diagnosable failure rather than a silent misplacement.
"""

from __future__ import annotations

import zlib
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from .container import GripReader
from .model import (
    DIR_XNEG,
    MM_PER_INCH,
    Manifest,
    PassRow,
    PenSpec,
    mm_to_dots,
)

PT_PER_INCH = 72.0


@dataclass
class PageProof:
    """Per-pen full-page masks for one page, in page-raster orientation."""

    page: int
    rows: int
    columns: int
    width_mm: float
    height_mm: float
    planes: Dict[int, np.ndarray]  # pen index -> (rows, columns) bool
    pass_boxes: List[Tuple[int, int, int, int, str]]  # x0,y0,x1,y1 (raster), dir


def compose_page(reader: GripReader, page: int) -> PageProof:
    m = reader.manifest
    rows = max(1, int(round(mm_to_dots(m.page_height, m.dpi_media))))
    cols = max(1, int(round(mm_to_dots(m.page_width, m.dpi_scan))))

    planes = {
        spec.index: np.zeros((rows, cols), dtype=bool) for spec in m.pen_specs
    } or {p: np.zeros((rows, cols), dtype=bool) for p in range(m.pens)}
    boxes: List[Tuple[int, int, int, int, str]] = []

    for row in reader.rows_for_page(page):
        for pen_index in sorted(planes):
            try:
                spec = m.pen(pen_index)
            except Exception:
                spec = PenSpec(index=pen_index)
            sw = reader.swath(page, row.index, pen_index)
            _blit(planes[pen_index], m, row, spec, sw, boxes if pen_index == 0 else None)

    return PageProof(
        page=page,
        rows=rows,
        columns=cols,
        width_mm=m.page_width,
        height_mm=m.page_height,
        planes=planes,
        pass_boxes=boxes,
    )


def _blit(
    plane: np.ndarray,
    m: Manifest,
    row: PassRow,
    spec: PenSpec,
    sw,
    boxes: Optional[List],
) -> None:
    bits = np.asarray(sw.bits, dtype=bool)

    # The one conditional.  After this, line index runs low-x to high-x.
    if row.dir == DIR_XNEG:
        bits = bits[::-1]

    # (columns, rows) file space -> (rows, columns) page-raster space.
    tile = bits.T

    x0 = row.origin_x + spec.offset_x
    # Character 0 is the nozzle nearest AA: the top of this pen's band.
    y_top = row.origin_y + spec.offset_y + sw.rows * MM_PER_INCH / m.dpi_media

    col0 = int(round(mm_to_dots(x0, m.dpi_scan)))
    row0 = int(round(mm_to_dots(m.page_height - y_top, m.dpi_media)))

    ph, pw = plane.shape
    th, tw = tile.shape

    # Page size is the media extent, not the image extent. A pass may legally
    # sit outside it — bleed, overspray beyond trim — so clip, never fault.
    src_r0, dst_r0 = max(0, -row0), max(0, row0)
    src_c0, dst_c0 = max(0, -col0), max(0, col0)
    h = min(th - src_r0, ph - dst_r0)
    w = min(tw - src_c0, pw - dst_c0)

    if boxes is not None:
        boxes.append((col0, row0, col0 + tw, row0 + th, row.dir))

    if h <= 0 or w <= 0:
        return
    dst = plane[dst_r0 : dst_r0 + h, dst_c0 : dst_c0 + w]
    np.logical_or(dst, tile[src_r0 : src_r0 + h, src_c0 : src_c0 + w], out=dst)


# --------------------------------------------------------------------------
# PNG
# --------------------------------------------------------------------------


def to_rgb(
    proof: PageProof,
    manifest: Manifest,
    background: Tuple[int, int, int] = (255, 255, 255),
    overlay_passes: bool = False,
) -> np.ndarray:
    """Composite the pen planes by multiply, the way ink stacks."""
    img = np.empty((proof.rows, proof.columns, 3), dtype=np.float32)
    img[:] = np.asarray(background, dtype=np.float32) / 255.0

    for pen_index in sorted(proof.planes):
        mask = proof.planes[pen_index]
        if not mask.any():
            continue
        try:
            colour = np.asarray(manifest.pen(pen_index).srgb_tuple(), dtype=np.float32)
        except Exception:
            colour = np.zeros(3, dtype=np.float32)
        img[mask] *= colour

    out = np.clip(img * 255.0 + 0.5, 0, 255).astype(np.uint8)

    if overlay_passes:
        for x0, y0, x1, y1, direction in proof.pass_boxes:
            tint = (255, 40, 40) if direction == DIR_XNEG else (40, 90, 255)
            _outline(out, x0, y0, x1, y1, tint)
    return out


def _outline(img: np.ndarray, x0: int, y0: int, x1: int, y1: int, colour) -> None:
    h, w = img.shape[:2]
    xs = slice(max(0, x0), min(w, x1))
    ys = slice(max(0, y0), min(h, y1))
    for y in (y0, y1 - 1):
        if 0 <= y < h:
            img[y, xs] = colour
    for x in (x0, x1 - 1):
        if 0 <= x < w:
            img[ys, x] = colour


def write_png(
    proof: PageProof,
    manifest: Manifest,
    path: str,
    max_dimension: Optional[int] = None,
    overlay_passes: bool = False,
) -> None:
    from PIL import Image

    arr = to_rgb(proof, manifest, overlay_passes=overlay_passes)
    img = Image.fromarray(arr, mode="RGB")
    if max_dimension and max(img.size) > max_dimension:
        scale = max_dimension / max(img.size)
        img = img.resize(
            (max(1, int(img.width * scale)), max(1, int(img.height * scale))),
            Image.LANCZOS,
        )
    img.save(path, optimize=True)


# --------------------------------------------------------------------------
# PDF
# --------------------------------------------------------------------------


class _Pdf:
    """A deliberately small PDF writer.

    1-bit masks map onto PDF `ImageMask` + a lossless filter almost directly:
    set bits paint the fill colour, clear bits leave the page alone.  One
    mask per pen, composited by multiply, no flattening to RGB.
    """

    def __init__(self) -> None:
        self.objects: List[Optional[bytes]] = []

    def reserve(self) -> int:
        self.objects.append(None)
        return len(self.objects)

    def put(self, number: int, body: bytes) -> None:
        self.objects[number - 1] = body

    def add(self, body: bytes) -> int:
        n = self.reserve()
        self.put(n, body)
        return n

    def stream(self, dict_entries: str, data: bytes) -> int:
        body = (
            f"<< {dict_entries} /Length {len(data)} >>\nstream\n".encode("ascii")
            + data
            + b"\nendstream"
        )
        return self.add(body)

    def serialise(self, root: int) -> bytes:
        out = bytearray(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n")
        offsets = [0] * (len(self.objects) + 1)
        for i, body in enumerate(self.objects, start=1):
            if body is None:
                body = b"null"
            offsets[i] = len(out)
            out += f"{i} 0 obj\n".encode("ascii") + body + b"\nendobj\n"
        xref = len(out)
        out += f"xref\n0 {len(self.objects) + 1}\n".encode("ascii")
        out += b"0000000000 65535 f \n"
        for i in range(1, len(self.objects) + 1):
            out += f"{offsets[i]:010d} 00000 n \n".encode("ascii")
        out += (
            f"trailer\n<< /Size {len(self.objects) + 1} /Root {root} 0 R >>\n"
            f"startxref\n{xref}\n%%EOF\n"
        ).encode("ascii")
        return bytes(out)


def write_pdf(
    proofs: Sequence[PageProof],
    manifest: Manifest,
    path: str,
    title: Optional[str] = None,
) -> None:
    pdf = _Pdf()
    catalog = pdf.reserve()
    pages_obj = pdf.reserve()

    gs = pdf.add(b"<< /Type /ExtGState /BM /Multiply >>")
    page_refs: List[int] = []

    for proof in proofs:
        w_pt = proof.width_mm / MM_PER_INCH * PT_PER_INCH
        h_pt = proof.height_mm / MM_PER_INCH * PT_PER_INCH

        xobjects: List[Tuple[str, int, Tuple[float, float, float]]] = []
        for pen_index in sorted(proof.planes):
            mask = proof.planes[pen_index]
            if not mask.any():
                continue
            packed = np.packbits(mask, axis=1).tobytes()
            data = zlib.compress(packed, 9)
            ref = pdf.stream(
                "/Type /XObject /Subtype /Image "
                f"/Width {proof.columns} /Height {proof.rows} "
                "/ImageMask true /BitsPerComponent 1 /Decode [1 0] "
                "/Filter /FlateDecode",
                data,
            )
            try:
                colour = manifest.pen(pen_index).srgb_tuple()
            except Exception:
                colour = (0.0, 0.0, 0.0)
            xobjects.append((f"Im{pen_index}", ref, colour))

        content = [f"/GSmul gs"]
        for name, _ref, (r, g, b) in xobjects:
            content.append("q")
            content.append(f"{r:.5f} {g:.5f} {b:.5f} rg")
            content.append(f"{w_pt:.4f} 0 0 {h_pt:.4f} 0 0 cm")
            content.append(f"/{name} Do")
            content.append("Q")
        stream_data = zlib.compress(("\n".join(content) + "\n").encode("ascii"), 9)
        content_ref = pdf.stream("/Filter /FlateDecode", stream_data)

        xo = " ".join(f"/{name} {ref} 0 R" for name, ref, _ in xobjects)
        page_ref = pdf.add(
            (
                f"<< /Type /Page /Parent {pages_obj} 0 R "
                f"/MediaBox [0 0 {w_pt:.4f} {h_pt:.4f}] "
                f"/Resources << /XObject << {xo} >> "
                f"/ExtGState << /GSmul {gs} 0 R >> >> "
                f"/Contents {content_ref} 0 R >>"
            ).encode("ascii")
        )
        page_refs.append(page_ref)

    kids = " ".join(f"{r} 0 R" for r in page_refs)
    pdf.put(
        pages_obj,
        f"<< /Type /Pages /Count {len(page_refs)} /Kids [{kids}] >>".encode("ascii"),
    )

    info = pdf.add(
        (
            "<< /Producer (dropspec-tools grip-render) "
            f"/Title ({_pdf_text(title or manifest.job_name)}) >>"
        ).encode("ascii")
    )
    pdf.put(catalog, f"<< /Type /Catalog /Pages {pages_obj} 0 R >>".encode("ascii"))

    data = pdf.serialise(catalog)
    # Splice /Info into the trailer without a second serialisation pass.
    data = data.replace(
        f"/Root {catalog} 0 R >>".encode("ascii"),
        f"/Root {catalog} 0 R /Info {info} 0 R >>".encode("ascii"),
    )
    with open(path, "wb") as fh:
        fh.write(data)


def _pdf_text(value: str) -> str:
    return (
        value.replace("\\", r"\\")
        .replace("(", r"\(")
        .replace(")", r"\)")
        .encode("ascii", "replace")
        .decode("ascii")
    )
