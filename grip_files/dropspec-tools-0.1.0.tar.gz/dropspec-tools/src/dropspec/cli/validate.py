"""`grip-validate` — the seven checks, in the order they fail usefully."""

from __future__ import annotations

import argparse
import sys
from typing import List, Optional

from ..validate import validate


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="grip-validate",
        description="Validate a DROPSpec .grip container.",
    )
    p.add_argument("input", nargs="+", help="one or more .grip containers")
    p.add_argument("--shallow", action="store_true",
                   help="skip decoding swath bodies (checks 1, 3, 6, 7 only)")
    p.add_argument("-q", "--quiet", action="store_true",
                   help="print nothing; the exit status is the answer")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    worst = 0
    for path in args.input:
        report = validate(path, deep=not args.shallow)
        if not args.quiet:
            for finding in report.findings:
                print(f"{path}: {finding}", file=sys.stderr)
            status = "ok" if report.ok else "FAILED"
            print(
                f"{path}: {status} "
                f"({report.checked_swaths} swath(s) checked, "
                f"{len(report.faults)} fault(s), "
                f"{len(report.warnings)} warning(s))"
            )
        if not report.ok:
            worst = 1
    return worst


if __name__ == "__main__":
    raise SystemExit(main())
