"""`grip-render` — a `.grip` in, a PDF or PNG proof out."""

from __future__ import annotations

import argparse
import os
import sys
from typing import List, Optional

from ..container import GripReader
from ..model import GripError
from ..render import compose_page, write_pdf, write_png


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="grip-render",
        description=(
            "Render a .grip to PDF or PNG. If the proof looks right the file "
            "is right, before a drop of ink. The proof consumes informative "
            "manifest data to choose ink colours, so a colour mismatch is "
            "not a spec violation."
        ),
    )
    p.add_argument("input", help="a .grip container")
    p.add_argument("-o", "--output",
                   help="output .pdf or .png (default: input stem + .pdf). "
                        "For multi-page PNG output, %%d is replaced with the "
                        "page number")
    p.add_argument("--page", type=int, action="append",
                   help="render only this page; repeatable")
    p.add_argument("--max-dimension", type=int, default=2400,
                   help="downsample PNG output to this longest edge "
                        "(default 2400; 0 for full resolution)")
    p.add_argument("--overlay-passes", action="store_true",
                   help="outline each pass's swath: blue XPOS, red XNEG")
    p.add_argument("-q", "--quiet", action="store_true")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    out = args.output or os.path.splitext(os.path.basename(args.input))[0] + ".pdf"
    is_png = out.lower().endswith(".png")

    try:
        with GripReader(args.input) as reader:
            pages = args.page or reader.pages
            missing = [p for p in pages if p not in reader.pages]
            if missing:
                raise GripError(f"{args.input} has no page(s) {missing}")

            proofs = []
            for page in pages:
                if not args.quiet:
                    print(f"composing page {page}", file=sys.stderr)
                proofs.append(compose_page(reader, page))

            if is_png:
                multi = len(proofs) > 1
                for proof in proofs:
                    path = out
                    if multi:
                        path = (
                            out.replace("%d", str(proof.page))
                            if "%d" in out
                            else f"{out[:-4]}-{proof.page:03d}.png"
                        )
                    write_png(
                        proof,
                        reader.manifest,
                        path,
                        max_dimension=args.max_dimension or None,
                        overlay_passes=args.overlay_passes,
                    )
                    if not args.quiet:
                        print(f"wrote {path}", file=sys.stderr)
            else:
                write_pdf(proofs, reader.manifest, out)
                if not args.quiet:
                    print(f"wrote {out}", file=sys.stderr)
    except GripError as exc:
        print(f"grip-render: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
