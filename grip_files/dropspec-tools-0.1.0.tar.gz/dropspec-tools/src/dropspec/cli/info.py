"""`grip-info` — say what is in a container without unzipping it by hand."""

from __future__ import annotations

import argparse
import sys
from typing import List, Optional

from ..container import GripReader
from ..model import GripError, dots_to_mm


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="grip-info", description="Summarise a .grip container."
    )
    p.add_argument("input")
    p.add_argument("--passes", action="store_true", help="list every pass")
    p.add_argument("--gcode", action="store_true", help="print command.gcode")
    p.add_argument("--manifest", action="store_true", help="print manifest.ini")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        with GripReader(args.input) as reader:
            m = reader.manifest
            if args.manifest:
                from .. import manifest_io

                print(manifest_io.dumps(m), end="")
                return 0
            if args.gcode:
                print(reader.gcode, end="")
                return 0

            print(f"job          {m.job_name}")
            print(f"created      {m.created}")
            print(f"container    version {m.version}, profile {m.profile}")
            print(f"media        {m.page_width} x {m.page_height} mm")
            print(f"resolution   {m.dpi_scan} dpi scan, {m.dpi_media} dpi media")
            print(f"head         {m.pens} pen(s), {m.nozzles_per_pen} nozzles each "
                  f"({dots_to_mm(m.nozzles_per_pen, m.dpi_media):.3f} mm array)")
            print(f"swath        {m.swath_height_mm:.3f} mm")
            print(f"pages        {m.pages}")
            print(f"passes       {m.passes_total} "
                  f"({len(reader.swath_names)} swath files)")
            print(f"rip          {m.generator} {m.generator_version}, "
                  f"halftone {m.halftone}, overlap {m.overlap_nozzles} nozzle(s)")
            for spec in m.pen_specs:
                print(
                    f"  pen {spec.index:02d}   {spec.colorant:<10} "
                    f"offset ({spec.offset_x:g}, {spec.offset_y:g}) mm   "
                    f"{spec.planned_droplets:,} droplets, "
                    f"{spec.planned_consumption:.4f} mL planned "
                    f"@ {spec.drop_volume_pl:g} pL"
                )
            if args.passes:
                print("\npage pass  origin_x  origin_y  dir")
                for r in reader.rows:
                    print(f"{r.page:>4} {r.index:>4} {r.origin_x:>9.3f} "
                          f"{r.origin_y:>9.3f}  {r.dir}")
    except GripError as exc:
        print(f"grip-info: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
