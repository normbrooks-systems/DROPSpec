"""`grip-write` — a document in, a `.grip` out."""

from __future__ import annotations

import argparse
import os
import sys
from typing import List, Optional

from .. import raster
from ..gcode import GcodeOptions
from ..model import GripError
from ..profile import PROFILES, MachineProfile
from ..rip import RipOptions, rip


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="grip-write",
        description=(
            "Rip a document into a DROPSpec .grip job container. "
            "PDFs and images are read directly; anything else LibreOffice "
            "can open is converted to PDF first."
        ),
    )
    p.add_argument("input", help="PDF, image, or any LibreOffice-openable document")
    p.add_argument("-o", "--output", help="output .grip (default: input stem + .grip)")

    g = p.add_argument_group("press")
    g.add_argument("--profile", default="ddp01-mono", choices=sorted(PROFILES),
                   help="machine profile (default: ddp01-mono)")
    g.add_argument("--pens", type=int, help="override pen count")
    g.add_argument("--nozzles", type=int, help="override nozzles per pen")
    g.add_argument("--dpi-scan", type=int, help="cross-axis dpi (encoder ticks per fire)")
    g.add_argument("--dpi-media", type=int, help="down-axis dpi (nozzle pitch)")
    g.add_argument("--overlap", type=int, help="stitch overlap in nozzles (O3)")
    g.add_argument("--lead", type=float, help="clear lead-in/out on the scan axis, mm")

    r = p.add_argument_group("rip")
    r.add_argument("--halftone", default="floyd-steinberg",
                   choices=["floyd-steinberg", "bayer", "threshold", "none"])
    r.add_argument("--threshold", type=float, default=0.5,
                   help="level for --halftone threshold (default 0.5)")
    r.add_argument("--bayer-order", type=int, default=3)
    r.add_argument("--gamma", type=float, default=1.0,
                   help="tone curve applied to ink coverage before screening")
    r.add_argument("--page-size", help="letter | a4 | WIDTHxHEIGHT in mm "
                                       "(default: the PDF MediaBox)")
    r.add_argument("--pages", help="page range, e.g. 1-4,7 (PDF input only)")
    r.add_argument("--fit", default="contain", choices=["contain", "stretch"],
                   help="how an image input is placed on the media")
    r.add_argument("--unidirectional", action="store_true",
                   help="every pass XPOS; default alternates")
    r.add_argument("--no-feather", action="store_true",
                   help="hard butt joints at band boundaries instead of a "
                        "dithered ramp across the overlap")
    r.add_argument("--job-name", help="free text for the queue UI and log lines")
    r.add_argument("-z", "--compress", type=int, default=6, choices=range(0, 10),
                   metavar="0-9", help="deflate level (default 6)")

    m = p.add_argument_group("motion")
    m.add_argument("--print-speed", type=float, default=625.0,
                   help="mm/s during a firing sweep (default 625)")
    m.add_argument("--travel-speed", type=float, default=800.0)
    m.add_argument("--advance-speed", type=float, default=100.0)

    p.add_argument("-q", "--quiet", action="store_true")
    return p


def parse_pages(text: Optional[str]) -> Optional[List[int]]:
    if not text:
        return None
    out: List[int] = []
    for chunk in text.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            a, _, b = chunk.partition("-")
            out.extend(range(int(a), int(b) + 1))
        else:
            out.append(int(chunk))
    return out


def resolve_profile(args) -> MachineProfile:
    base = PROFILES[args.profile]
    kwargs = dict(
        name=base.name,
        pens=args.pens if args.pens else base.pens,
        nozzles_per_pen=args.nozzles if args.nozzles else base.nozzles_per_pen,
        dpi_media=args.dpi_media if args.dpi_media else base.dpi_media,
        dpi_scan=args.dpi_scan if args.dpi_scan else base.dpi_scan,
        overlap_nozzles=base.overlap_nozzles if args.overlap is None else args.overlap,
        mode=base.mode,
        colorants=list(base.colorants),
        srgb_hints=list(base.srgb_hints),
        drop_volume_pl=base.drop_volume_pl,
        lead_mm=base.lead_mm if args.lead is None else args.lead,
        pen_offsets_x=list(base.pen_offsets_x),
    )
    if args.pens and args.pens != base.pens:
        colorants = list(base.colorants)[: args.pens]
        while len(colorants) < args.pens:
            colorants.append(colorants[-1] if colorants else "black")
        kwargs["colorants"] = colorants
        kwargs["srgb_hints"] = list(base.srgb_hints)[: args.pens]
    return MachineProfile(**kwargs)


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    try:
        profile = resolve_profile(args)
        out = args.output or os.path.splitext(os.path.basename(args.input))[0] + ".grip"

        if not args.quiet:
            print(f"reading  {args.input}", file=sys.stderr)
        pages = raster.load(
            args.input,
            dpi_scan=profile.dpi_scan,
            dpi_media=profile.dpi_media,
            page_size=args.page_size,
            gamma=args.gamma,
            pages=parse_pages(args.pages),
            fit=args.fit,
        )
        if not args.quiet:
            first = pages[0]
            print(
                f"         {len(pages)} page(s), "
                f"{first.width_mm:.1f} x {first.height_mm:.1f} mm, "
                f"{first.columns} x {first.rows} dots",
                file=sys.stderr,
            )

        options = RipOptions(
            job_name=args.job_name or os.path.basename(args.input),
            halftone=args.halftone,
            threshold_level=args.threshold,
            bayer_order=args.bayer_order,
            bidirectional=not args.unidirectional,
            feather=not args.no_feather,
            compresslevel=args.compress,
            gcode=GcodeOptions(
                print_speed_mm_s=args.print_speed,
                travel_speed_mm_s=args.travel_speed,
                advance_speed_mm_s=args.advance_speed,
            ),
        )
        manifest = rip(pages, profile, out, options)
    except (GripError, NotImplementedError, ValueError) as exc:
        print(f"grip-write: {exc}", file=sys.stderr)
        return 2

    if not args.quiet:
        size = os.path.getsize(out)
        print(
            f"wrote    {out}  "
            f"{manifest.pages} page(s), {manifest.passes_total} pass(es), "
            f"{manifest.pens} pen(s), {size / 1e6:.2f} MB",
            file=sys.stderr,
        )
        for spec in manifest.pen_specs:
            print(
                f"         pen {spec.index:02d} {spec.colorant:<10} "
                f"{spec.planned_droplets:>12,} droplets  "
                f"{spec.planned_consumption:.4f} mL planned",
                file=sys.stderr,
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
