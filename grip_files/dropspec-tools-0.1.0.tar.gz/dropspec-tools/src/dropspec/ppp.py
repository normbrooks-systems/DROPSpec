"""`.ppp` swath files — plain text, one line per column, one character per nozzle.

    # ROWS:300 COLUMNS:5100 PAGE:001 PASS:001 PEN:00 ACTIVE:8 INACTIVE:. DIR:XPOS
    ..........8888888888888888..........;
    ..........8888888888888888..........;

Line length is exactly ROWS + 1; the character at index ROWS is `;`.  LF line
endings; parsers tolerate CRLF, since `;` is the true terminator.

Column-major because that is the consumption axis — one column per fire
event.  There is no empty-column shorthand and there will not be one: it
compresses to nothing anyway, and it destroys the fixed-width invariant that
is the entire integrity story.
"""

from __future__ import annotations

from typing import Dict, Tuple

import numpy as np

from .model import (
    ACTIVE_DEFAULT,
    DIRECTIONS,
    GripFormatError,
    INACTIVE_DEFAULT,
    Swath,
    TERMINATOR,
)

_HEADER_KEYS = ("ROWS", "COLUMNS", "PAGE", "PASS", "PEN", "ACTIVE", "INACTIVE", "DIR")

#: The header is space-delimited, so a glyph that *is* a space cannot be
#: written literally.  `SP` is the escape.  Space remains the documented
#: alternate INACTIVE glyph for hand-authored fixtures, never for RIP output
#: — see docs/spec-findings.md, finding 2.
SPACE_TOKEN = "SP"


def _encode_glyph(glyph: str) -> str:
    return SPACE_TOKEN if glyph == " " else glyph


def _decode_glyph(token: str) -> str:
    return " " if token == SPACE_TOKEN else token


def format_header(sw: Swath) -> str:
    return (
        f"# ROWS:{sw.rows} COLUMNS:{sw.columns} "
        f"PAGE:{sw.page:03d} PASS:{sw.index:03d} PEN:{sw.pen:02d} "
        f"ACTIVE:{_encode_glyph(sw.active)} "
        f"INACTIVE:{_encode_glyph(sw.inactive)} DIR:{sw.dir}"
    )


def parse_header(line: str) -> Dict[str, str]:
    """Strict parse of the `#`-prefixed header line."""
    if not line.startswith("#"):
        raise GripFormatError("line 1: .ppp must open with a '#' header line")
    fields: Dict[str, str] = {}
    for token in line[1:].split():
        if ":" not in token:
            raise GripFormatError(f"line 1: header token {token!r} is not KEY:VALUE")
        key, _, value = token.partition(":")
        if not key or not value:
            raise GripFormatError(f"line 1: header token {token!r} is not KEY:VALUE")
        if key in fields:
            raise GripFormatError(f"line 1: header key {key} given twice")
        fields[key] = value
    missing = [k for k in _HEADER_KEYS if k not in fields]
    if missing:
        raise GripFormatError(f"line 1: header missing {', '.join(missing)}")
    return fields


def dumps(sw: Swath) -> bytes:
    """Serialise a swath.  Returns bytes: the format is ASCII by construction."""
    bits = np.asarray(sw.bits, dtype=bool)
    if bits.shape != (sw.columns, sw.rows):
        raise GripFormatError(
            f"{sw.filename}: bits shape {bits.shape} != "
            f"(columns {sw.columns}, rows {sw.rows})"
        )
    if len(sw.active) != 1 or len(sw.inactive) != 1:
        raise GripFormatError("ACTIVE and INACTIVE must each be a single character")

    stride = sw.rows + 2  # ROWS nozzles + ';' + '\n'
    buf = np.empty((sw.columns, stride), dtype=np.uint8)
    buf[:, : sw.rows] = np.where(
        bits, ord(sw.active), ord(sw.inactive)
    ).astype(np.uint8)
    buf[:, sw.rows] = ord(TERMINATOR)
    buf[:, sw.rows + 1] = ord("\n")

    return (format_header(sw) + "\n").encode("ascii") + buf.tobytes()


def loads(data: bytes, name: str = "<ppp>") -> Swath:
    """Parse a swath.  Failures report a line number, which is the whole point."""
    if isinstance(data, str):
        data = data.encode("ascii")

    nl = data.find(b"\n")
    if nl < 0:
        raise GripFormatError(f"{name}: no header line")
    header = parse_header(data[:nl].rstrip(b"\r").decode("ascii", "replace"))

    try:
        rows = int(header["ROWS"])
        columns = int(header["COLUMNS"])
        page = int(header["PAGE"])
        index = int(header["PASS"])
        pen = int(header["PEN"])
    except ValueError as exc:
        raise GripFormatError(f"{name} line 1: non-integer header field: {exc}") from exc

    active = _decode_glyph(header["ACTIVE"])
    inactive = _decode_glyph(header["INACTIVE"])
    direction = header["DIR"]
    if direction not in DIRECTIONS:
        raise GripFormatError(f"{name} line 1: DIR:{direction} is not XPOS or XNEG")
    if len(active) != 1 or len(inactive) != 1:
        raise GripFormatError(f"{name} line 1: ACTIVE/INACTIVE must be one character")
    if active == inactive:
        raise GripFormatError(f"{name} line 1: ACTIVE and INACTIVE are the same glyph")

    body = data[nl + 1 :]
    bits = _decode_body(body, rows, columns, active, inactive, name)

    return Swath(
        page=page,
        index=index,
        pen=pen,
        rows=rows,
        columns=columns,
        dir=direction,
        bits=bits,
        active=active,
        inactive=inactive,
    )


def _decode_body(
    body: bytes, rows: int, columns: int, active: str, inactive: str, name: str
) -> np.ndarray:
    stride = rows + 2
    arr = np.frombuffer(body, dtype=np.uint8)

    # Fast path: exactly `columns` LF-terminated fixed-width lines.
    if arr.size == columns * stride:
        grid = arr.reshape(columns, stride)
        if (
            np.all(grid[:, rows] == ord(TERMINATOR))
            and np.all(grid[:, rows + 1] == ord("\n"))
        ):
            cells = grid[:, :rows]
            act = cells == ord(active)
            ina = cells == ord(inactive)
            if np.all(act | ina):
                return act
    return _decode_body_slow(body, rows, columns, active, inactive, name)


def _decode_body_slow(
    body: bytes, rows: int, columns: int, active: str, inactive: str, name: str
) -> np.ndarray:
    """Line-by-line.  Slower, but it can name the line that is wrong."""
    lines = body.split(b"\n")
    if lines and lines[-1] == b"":
        lines.pop()

    bits = np.zeros((columns, rows), dtype=bool)
    a, i = ord(active), ord(inactive)

    for n, raw in enumerate(lines):
        line_no = n + 2  # header is line 1
        line = raw.rstrip(b"\r")
        if n >= columns:
            raise GripFormatError(
                f"{name} line {line_no}: more data lines than COLUMNS ({columns})"
            )
        if len(line) != rows + 1:
            raise GripFormatError(
                f"{name} line {line_no}: length {len(line)}, expected ROWS+1 "
                f"({rows + 1})"
            )
        if line[rows] != ord(TERMINATOR):
            raise GripFormatError(
                f"{name} line {line_no}: not terminated with {TERMINATOR!r}"
            )
        cells = np.frombuffer(line[:rows], dtype=np.uint8)
        act = cells == a
        bad = ~(act | (cells == i))
        if bad.any():
            col = int(np.argmax(bad))
            raise GripFormatError(
                f"{name} line {line_no} character {col}: "
                f"{chr(cells[col])!r} is neither ACTIVE {active!r} nor "
                f"INACTIVE {inactive!r}"
            )
        bits[n] = act

    if len(lines) != columns:
        raise GripFormatError(
            f"{name}: {len(lines)} data lines, header declares COLUMNS {columns}"
        )
    return bits
