"""The cheap checks, in the order they fail usefully.

Straight from the format notes:

1. `profile` is `sheet`, else refuse
2. Every `.ppp` line is exactly `ROWS + 1` characters, terminated `;`,
   containing only the declared `ACTIVE` and `INACTIVE` glyphs.  Failure
   reports a **line number**
3. `.ppp` header `PAGE`/`PASS`/`PEN` agree with the filename
4. `.ppp` header `DIR` agrees with `passes.csv`
5. `ROWS` agrees with `nozzles_per_pen`
6. `passes_total` agrees with the `passes.csv` row count
7. Every `(page, pass)` in `passes.csv` has a full set of `pens` swath files

Text validation is *stronger* than the binary equivalent, not weaker: packed
binary gives "file length is a multiple of stride"; text gives a specific
corrupt line number.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from .container import GripReader, RIP_PREFIX
from .model import (
    GripError,
    GripFormatError,
    PROFILE_SHEET,
    parse_swath_filename,
)

FAULT = "FAULT"
WARN = "WARN"


@dataclass
class Finding:
    level: str
    check: str
    message: str
    member: Optional[str] = None

    def __str__(self) -> str:
        where = f" [{self.member}]" if self.member else ""
        return f"{self.level}  {self.check}{where}: {self.message}"


@dataclass
class Report:
    path: str
    findings: List[Finding] = field(default_factory=list)
    checked_swaths: int = 0

    def add(self, level: str, check: str, message: str, member: Optional[str] = None):
        self.findings.append(Finding(level, check, message, member))

    @property
    def faults(self) -> List[Finding]:
        return [f for f in self.findings if f.level == FAULT]

    @property
    def warnings(self) -> List[Finding]:
        return [f for f in self.findings if f.level == WARN]

    @property
    def ok(self) -> bool:
        return not self.faults


def validate(path: str, deep: bool = True) -> Report:
    """Validate a `.grip`.  `deep=False` skips decoding swath bodies."""
    report = Report(path=path)

    try:
        reader = GripReader(path)
    except GripError as exc:
        report.add(FAULT, "container", str(exc))
        return report

    with reader:
        m = reader.manifest

        # 1 -- profile ------------------------------------------------------
        if m.profile != PROFILE_SHEET:
            report.add(
                FAULT,
                "1 profile",
                f"profile = {m.profile!r}; a v1 reader refuses anything but "
                f"{PROFILE_SHEET!r} rather than guessing field widths",
            )
            return report

        if not m.version.startswith("0.") and m.version != "1.0":
            report.add(WARN, "1 profile", f"unfamiliar container version {m.version!r}")

        row_by_key = {r.key: r for r in reader.rows}

        # 6 -- passes_total -------------------------------------------------
        if m.passes_total != len(reader.rows):
            report.add(
                FAULT,
                "6 passes_total",
                f"manifest says {m.passes_total}, passes.csv has "
                f"{len(reader.rows)} rows. passes.csv is the source; "
                "passes_total is a check",
            )
        declared_pages = {r.page for r in reader.rows}
        if m.pages != len(declared_pages):
            report.add(
                FAULT,
                "6 pages",
                f"manifest says {m.pages} page(s), passes.csv covers "
                f"{len(declared_pages)}",
            )

        # 7 -- full set of pens per pass ------------------------------------
        index = reader.swath_index()
        expected = set(range(m.pens))
        for key in sorted(row_by_key):
            found = set(index.get(key, []))
            if found != expected:
                missing = sorted(expected - found)
                extra = sorted(found - expected)
                parts = []
                if missing:
                    parts.append(f"missing pen(s) {missing}")
                if extra:
                    parts.append(f"unexpected pen(s) {extra}")
                report.add(
                    FAULT,
                    "7 pen set",
                    f"page {key[0]} pass {key[1]}: " + ", ".join(parts),
                )
        for key in sorted(set(index) - set(row_by_key)):
            report.add(
                FAULT,
                "7 pen set",
                f"rip/ holds swaths for page {key[0]} pass {key[1]}, which is "
                "not a row in passes.csv",
            )

        if not reader.has_gcode:
            report.add(WARN, "container", "no command.gcode member")

        # 2-5 -- per-swath ---------------------------------------------------
        for name in reader.swath_names:
            try:
                page, index_, pen = parse_swath_filename(name)
            except GripFormatError as exc:
                report.add(FAULT, "3 filename", str(exc), name)
                continue

            if not deep:
                continue

            try:
                sw = reader.swath_by_name(name)
            except GripFormatError as exc:
                # Check 2 lives inside the parser: it is the one that can
                # name the offending line.
                report.add(FAULT, "2 swath body", str(exc), name)
                continue
            report.checked_swaths += 1

            if (sw.page, sw.index, sw.pen) != (page, index_, pen):
                report.add(
                    FAULT,
                    "3 filename",
                    f"header says PAGE:{sw.page:03d} PASS:{sw.index:03d} "
                    f"PEN:{sw.pen:02d}, filename says {page:03d}_{index_:03d}_"
                    f"{pen:02d}",
                    name,
                )

            row = row_by_key.get((page, index_))
            if row is None:
                continue
            if sw.dir != row.dir:
                report.add(
                    FAULT,
                    "4 dir",
                    f"header DIR:{sw.dir}, passes.csv says {row.dir}. "
                    "passes.csv is authoritative",
                    name,
                )

            if sw.rows != m.nozzles_per_pen:
                report.add(
                    FAULT,
                    "5 rows",
                    f"ROWS:{sw.rows} but manifest nozzles_per_pen = "
                    f"{m.nozzles_per_pen}; this job was built for a "
                    "different head",
                    name,
                )

        if deep:
            _check_columns_agree(reader, report)
            _check_planned_droplets(reader, report)

    return report


def _check_columns_agree(reader: GripReader, report: Report) -> None:
    """All pens in a pass share one sweep, so they share COLUMNS."""
    by_pass = {}
    for name in reader.swath_names:
        try:
            page, index_, _pen = parse_swath_filename(name)
        except GripFormatError:
            continue
        try:
            sw = reader.swath_by_name(name)
        except GripFormatError:
            continue
        by_pass.setdefault((page, index_), {})[name] = sw.columns
    for key, cols in by_pass.items():
        if len(set(cols.values())) > 1:
            report.add(
                FAULT,
                "extra columns",
                f"page {key[0]} pass {key[1]}: pens disagree on COLUMNS "
                f"{sorted(set(cols.values()))}; one pass is one sweep",
            )


def _check_planned_droplets(reader: GripReader, report: Report) -> None:
    """`planned_droplets` is provenance, so a mismatch is a warning, not a fault."""
    counted = {spec.index: 0 for spec in reader.manifest.pen_specs}
    for name in reader.swath_names:
        try:
            _page, _index, pen = parse_swath_filename(name)
            sw = reader.swath_by_name(name)
        except GripFormatError:
            return
        if pen in counted:
            counted[pen] += int(np.count_nonzero(np.asarray(sw.bits)))
    for spec in reader.manifest.pen_specs:
        if spec.planned_droplets and spec.planned_droplets != counted[spec.index]:
            report.add(
                WARN,
                "provenance",
                f"pen {spec.index:02d}: manifest planned_droplets = "
                f"{spec.planned_droplets}, rasters contain "
                f"{counted[spec.index]}. [pen.nn] is provenance, not "
                "instruction, so this is informative",
            )
