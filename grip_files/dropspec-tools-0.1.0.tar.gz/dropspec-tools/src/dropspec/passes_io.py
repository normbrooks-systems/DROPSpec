"""`passes.csv` — read and write.

Comma-delimited, LF, header row required, no quoting: no field can contain a
comma.  Keyed on `(page, pass)`.  `page` and `pass` are written unpadded —
CSV is parsed, not sorted; the triple padding exists for filename lexical
sort and does not apply here.

Deliberately absent: swath extent (derivable as COLUMNS / dpi_scan, and
COLUMNS is in every `.ppp` header) and pen (all pens in a pass share origin
and direction by physics).
"""

from __future__ import annotations

import io
from typing import Iterable, List

from .model import GripFormatError, PassRow

HEADER = "page,pass,origin_x,origin_y,dir"


def _fmt(value: float) -> str:
    """Enough significant figures to survive a round trip, always a float.

    `planned_consumption` for a light page is microlitres, so a fixed number
    of decimal places would quietly round the provenance to zero.
    """
    text = f"{value:.9g}"
    if "." not in text and "e" not in text and "E" not in text:
        text += ".0"
    return text


def dumps(rows: Iterable[PassRow]) -> str:
    out = io.StringIO()
    out.write(HEADER + "\n")
    for r in rows:
        r.validate()
        out.write(
            f"{r.page},{r.index},{_fmt(r.origin_x)},{_fmt(r.origin_y)},{r.dir}\n"
        )
    return out.getvalue()


def loads(text: str) -> List[PassRow]:
    lines = text.replace("\r\n", "\n").split("\n")
    if not lines or lines[0].strip() != HEADER:
        raise GripFormatError(
            f"passes.csv header must be exactly {HEADER!r}, got {lines[0]!r}"
        )
    rows: List[PassRow] = []
    seen = set()
    for n, line in enumerate(lines[1:], start=2):
        if not line.strip():
            continue
        parts = line.split(",")
        if len(parts) != 5:
            raise GripFormatError(
                f"passes.csv line {n}: expected 5 fields, got {len(parts)}"
            )
        try:
            row = PassRow(
                page=int(parts[0]),
                index=int(parts[1]),
                origin_x=float(parts[2]),
                origin_y=float(parts[3]),
                dir=parts[4].strip(),
            )
        except ValueError as exc:
            raise GripFormatError(f"passes.csv line {n}: {exc}") from exc
        row.validate()
        if row.key in seen:
            raise GripFormatError(
                f"passes.csv line {n}: duplicate key "
                f"(page {row.page}, pass {row.index})"
            )
        seen.add(row.key)
        rows.append(row)
    return rows
