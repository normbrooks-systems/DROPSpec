"""Core data model for the `.grip` container.

Everything in here is deliberately dumb: dataclasses, constants, and the
arithmetic that turns page space into file space.  Parsing lives in `io_*`
modules, policy lives in `rip`, drawing lives in `render`.

Coordinate systems (from the format notes, restated because getting this
wrong is silent):

**Page space** — origin bottom-left, +x along scan, +y along media advance,
all geometry in millimetres.

**File space** — within a `.ppp`, line 0 is the first column *fired*, so on
`XNEG` passes line index runs from high x to low x.  Character 0 is the
nozzle nearest AA (the top face), so character index runs in *decreasing* y.

The mapping between them is `swath_placement()` below and nothing else.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

GRIP_VERSION = "0.3"

MM_PER_INCH = 25.4

#: Field widths are frozen.  Overflow is a hard fault; fields never widen.
MAX_PAGES = 999
MAX_PASSES_PER_PAGE = 999
MAX_PENS = 100

ACTIVE_DEFAULT = "8"
INACTIVE_DEFAULT = "."
TERMINATOR = ";"

DIR_XPOS = "XPOS"
DIR_XNEG = "XNEG"
DIRECTIONS = (DIR_XPOS, DIR_XNEG)

PROFILE_SHEET = "sheet"
PROFILE_ROLL = "roll"  # [RESERVED] — a v1 reader refuses it.


class GripError(Exception):
    """Base class for every fault this package raises."""


class GripFormatError(GripError):
    """The container, or a member of it, is not what the spec says it is."""


class GripOverflowError(GripError):
    """A frozen field width was exceeded.  Never widen; refuse the job."""


def mm_to_dots(mm: float, dpi: float) -> float:
    return mm * dpi / MM_PER_INCH


def dots_to_mm(dots: float, dpi: float) -> float:
    return dots * MM_PER_INCH / dpi


# --------------------------------------------------------------------------
# manifest.ini
# --------------------------------------------------------------------------


@dataclass
class PenSpec:
    """One `[pen.nn]` section.

    `colorant` is a *name* plus an optional sRGB hint, never a colour: a
    615 nm fluorescent, MICR and clear varnish have no honest sRGB value.

    `offset_x` / `offset_y` are the pen's nominal position in the gang,
    in millimetres, measured in page-space sense (+y along media advance)
    from the swath origin.  On the reference four-pen gang, pen 00 is the
    AA-most (top) pen and carries the largest `offset_y`.

    See `docs/pen-offset-clarification.md`: these are consumed by the
    renderer for *placement*.  Fine registration compensation is a separate
    thing, is already baked into the raster by the RIP, and is not
    re-applied here.

    `planned_droplets` / `planned_consumption` / `drop_volume_pl` are
    provenance: what the RIP intended, not a claim about reality.
    """

    index: int
    colorant: str = "black"
    srgb: Optional[str] = None
    offset_x: float = 0.0
    offset_y: float = 0.0
    planned_droplets: int = 0
    planned_consumption: float = 0.0
    drop_volume_pl: float = 30.0

    @property
    def section(self) -> str:
        return f"pen.{self.index:02d}"

    def srgb_tuple(self) -> Tuple[float, float, float]:
        """Best-effort ink colour for proofing.  Informative only."""
        if self.srgb:
            s = self.srgb.strip().lstrip("#")
            if len(s) == 6:
                return tuple(int(s[i : i + 2], 16) / 255.0 for i in (0, 2, 4))  # type: ignore[return-value]
        return _COLORANT_HINTS.get(self.colorant.lower(), (0.0, 0.0, 0.0))


_COLORANT_HINTS: Dict[str, Tuple[float, float, float]] = {
    "black": (0.0, 0.0, 0.0),
    "cyan": (0.0, 0.62, 0.88),
    "magenta": (0.90, 0.0, 0.55),
    "yellow": (1.0, 0.90, 0.0),
    "micr": (0.05, 0.05, 0.08),
    "varnish": (0.85, 0.85, 0.85),
}


@dataclass
class Manifest:
    """`manifest.ini` — what this job is.  Constant size, whatever the job length."""

    # [grip]
    version: str = GRIP_VERSION
    profile: str = PROFILE_SHEET
    job_name: str = "untitled"
    created: str = ""
    pages: int = 0
    passes_total: int = 0
    pens: int = 0

    # [geometry]
    nozzles_per_pen: int = 300
    dpi_scan: int = 600
    dpi_media: int = 600
    page_width: float = 215.9
    page_height: float = 279.4

    # [pen.nn]
    pen_specs: List[PenSpec] = field(default_factory=list)

    # [rip] — informative.  Consumers SHALL NOT alter behaviour on it.
    generator: str = "dropspec-tools"
    generator_version: str = "0.1.0"
    halftone: str = "floyd-steinberg"
    overlap_nozzles: int = 0
    interleave: int = 1

    @property
    def nozzle_pitch_mm(self) -> float:
        return MM_PER_INCH / self.dpi_media

    @property
    def column_pitch_mm(self) -> float:
        return MM_PER_INCH / self.dpi_scan

    @property
    def pen_array_height_mm(self) -> float:
        """Media-axis extent of one pen's nozzle array."""
        return dots_to_mm(self.nozzles_per_pen, self.dpi_media)

    @property
    def swath_height_mm(self) -> float:
        """Media-axis extent of the whole gang in one pass.

        Character 0 of pen 00's lines lies at `origin_y + swath_height_mm`.
        """
        if not self.pen_specs:
            return self.pen_array_height_mm
        return max(p.offset_y for p in self.pen_specs) + self.pen_array_height_mm

    def pen(self, index: int) -> PenSpec:
        for p in self.pen_specs:
            if p.index == index:
                return p
        raise GripFormatError(f"manifest has no [pen.{index:02d}] section")


# --------------------------------------------------------------------------
# passes.csv
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class PassRow:
    """One row of `passes.csv`.  Keyed on `(page, pass)`; authoritative for `dir`.

    `origin_x` is the swath's lowest-x edge and `origin_y` its bottom edge,
    both in millimetres in page space, both direction-independent.
    """

    page: int
    index: int  # `pass` is a keyword; the column is still called `pass`
    origin_x: float
    origin_y: float
    dir: str

    @property
    def key(self) -> Tuple[int, int]:
        return (self.page, self.index)

    def validate(self) -> None:
        if not 1 <= self.page <= MAX_PAGES:
            raise GripOverflowError(
                f"page {self.page} outside 1..{MAX_PAGES}; fields never widen"
            )
        if not 1 <= self.index <= MAX_PASSES_PER_PAGE:
            raise GripOverflowError(
                f"page {self.page} pass {self.index} outside "
                f"1..{MAX_PASSES_PER_PAGE}; fields never widen"
            )
        if self.dir not in DIRECTIONS:
            raise GripFormatError(f"dir {self.dir!r} is not XPOS or XNEG")


# --------------------------------------------------------------------------
# rip/PPP_SSS_NN.ppp
# --------------------------------------------------------------------------


def swath_filename(page: int, index: int, pen: int) -> str:
    """`PPP_SSS_NN.ppp` — page_pass_pen.

    Pages and passes are 1-based print ordinals; pens are 0-based hardware
    addresses.  The mixed base is deliberate.
    """
    if not 1 <= page <= MAX_PAGES:
        raise GripOverflowError(f"page {page} outside 1..{MAX_PAGES}")
    if not 1 <= index <= MAX_PASSES_PER_PAGE:
        raise GripOverflowError(f"pass {index} outside 1..{MAX_PASSES_PER_PAGE}")
    if not 0 <= pen < MAX_PENS:
        raise GripOverflowError(f"pen {pen} outside 0..{MAX_PENS - 1}")
    return f"{page:03d}_{index:03d}_{pen:02d}.ppp"


def parse_swath_filename(name: str) -> Tuple[int, int, int]:
    stem = name.rsplit("/", 1)[-1]
    if not stem.endswith(".ppp"):
        raise GripFormatError(f"{name!r} is not a .ppp member")
    body = stem[:-4]
    parts = body.split("_")
    if len(parts) != 3 or [len(p) for p in parts] != [3, 3, 2]:
        raise GripFormatError(f"{name!r} is not PPP_SSS_NN.ppp")
    try:
        page, index, pen = (int(p) for p in parts)
    except ValueError as exc:
        raise GripFormatError(f"{name!r} is not PPP_SSS_NN.ppp") from exc
    return page, index, pen


@dataclass
class Swath:
    """One `.ppp`: a self-describing 1-bit mask for one pen on one pass.

    `bits` is a boolean array of shape `(columns, rows)` in *file* order:
    `bits[line][char]`, line 0 being the first column fired and char 0 the
    nozzle nearest AA.
    """

    page: int
    index: int
    pen: int
    rows: int
    columns: int
    dir: str
    bits: "object"  # numpy.ndarray[bool], (columns, rows)
    active: str = ACTIVE_DEFAULT
    inactive: str = INACTIVE_DEFAULT

    @property
    def filename(self) -> str:
        return swath_filename(self.page, self.index, self.pen)


def swath_placement(
    manifest: Manifest, row: PassRow, pen: PenSpec, columns: int
) -> Tuple[float, float, float, float]:
    """Page-space bounding box of a swath, as `(x0, y0, x1, y1)` in mm.

    `x0`/`y0` are the low corner.  This is direction-independent: `dir` only
    decides which end line 0 sits at, which is the renderer's one conditional.
    """
    x0 = row.origin_x + pen.offset_x
    y0 = row.origin_y + pen.offset_y
    x1 = x0 + dots_to_mm(columns, manifest.dpi_scan)
    y1 = y0 + dots_to_mm(manifest.nozzles_per_pen, manifest.dpi_media)
    return x0, y0, x1, y1
