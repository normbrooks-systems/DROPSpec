"""DROPSpec reference tooling.

`.grip` (g-rip: gcode + rip) is the DROPSpec job container.  This package
implements the three things a reference implementation owes the spec:

* a **writer** (`dropspec.rip`)       — document in, `.grip` out
* a **reader/renderer** (`dropspec.render`) — `.grip` in, PDF or PNG proof out
* a **validator** (`dropspec.validate`)     — the seven cheap checks, in the
  order they fail usefully

Version of the *container format* this package reads and writes is
`GRIP_VERSION`; the package's own version is independent of it.
"""

from .model import (  # noqa: F401
    GRIP_VERSION,
    GripError,
    GripFormatError,
    GripOverflowError,
    Manifest,
    PassRow,
    PenSpec,
    Swath,
)

__all__ = [
    "GRIP_VERSION",
    "GripError",
    "GripFormatError",
    "GripOverflowError",
    "Manifest",
    "PassRow",
    "PenSpec",
    "Swath",
]

__version__ = "0.1.0"
