"""Input side of the RIP: a document becomes continuous-tone ink coverage.

Three input classes, one output shape:

* PDF                        — rendered with pypdfium2
* raster images              — read with Pillow
* anything LibreOffice opens — converted to PDF with `soffice --convert-to`,
  then treated as PDF

The output of this module is, per page, a float32 array of **ink coverage**
in `[0, 1]` with shape `(media_rows, scan_columns)`, row 0 at the top of the
page (decreasing y) and column 0 at x = 0.  Coverage, not luminance: 0 is
bare substrate, 1 is solid ink.  Screening has not happened yet.

Page size is the *media* extent, not the image extent — it is the PDF
MediaBox.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

import numpy as np
from PIL import Image

from .model import MM_PER_INCH, GripError

PT_PER_INCH = 72.0

IMAGE_SUFFIXES = {
    ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".pbm", ".pgm",
    ".ppm", ".webp",
}

PAGE_SIZES_MM = {
    "letter": (215.9, 279.4),
    "legal": (215.9, 355.6),
    "tabloid": (279.4, 431.8),
    "a3": (297.0, 420.0),
    "a4": (210.0, 297.0),
    "a5": (148.0, 210.0),
}


class RasterError(GripError):
    pass


@dataclass
class PageRaster:
    """One page of continuous-tone ink coverage, plus its media extent."""

    coverage: np.ndarray  # float32 (media_rows, scan_columns), 0..1
    width_mm: float
    height_mm: float

    @property
    def rows(self) -> int:
        return int(self.coverage.shape[0])

    @property
    def columns(self) -> int:
        return int(self.coverage.shape[1])


def parse_page_size(text: str) -> Tuple[float, float]:
    """`letter`, `a4`, or `WIDTHxHEIGHT` in millimetres."""
    key = text.strip().lower()
    if key in PAGE_SIZES_MM:
        return PAGE_SIZES_MM[key]
    if "x" in key:
        w, _, h = key.partition("x")
        try:
            return float(w), float(h)
        except ValueError:
            pass
    raise RasterError(
        f"page size {text!r} is not a known name or WIDTHxHEIGHT in mm"
    )


def _target_shape(width_mm: float, height_mm: float, dpi_scan: int, dpi_media: int):
    cols = max(1, int(round(width_mm * dpi_scan / MM_PER_INCH)))
    rows = max(1, int(round(height_mm * dpi_media / MM_PER_INCH)))
    return rows, cols


def _to_coverage(img: Image.Image, gamma: float, invert: bool) -> np.ndarray:
    """Luminance to ink coverage, with an optional tone curve."""
    if img.mode not in ("L", "1"):
        img = img.convert("L")
    a = np.asarray(img.convert("L"), dtype=np.float32) / 255.0
    cov = a if invert else 1.0 - a
    if gamma and abs(gamma - 1.0) > 1e-9:
        cov = np.clip(cov, 0.0, 1.0) ** (1.0 / gamma)
    return np.clip(cov, 0.0, 1.0).astype(np.float32)


# --------------------------------------------------------------------------
# LibreOffice bridge
# --------------------------------------------------------------------------


def soffice_binary() -> Optional[str]:
    for name in ("soffice", "libreoffice"):
        path = shutil.which(name)
        if path:
            return path
    return None


def convert_to_pdf(path: str, outdir: Optional[str] = None, timeout: int = 180) -> str:
    """Run a document through LibreOffice's headless PDF export.

    This is the same conversion the LibreOffice "export to .grip" macro
    performs; having it here means `grip-write report.odt` works from a
    shell too.
    """
    soffice = soffice_binary()
    if not soffice:
        raise RasterError(
            f"{os.path.basename(path)} needs LibreOffice to convert to PDF, "
            "and no soffice binary was found on PATH"
        )
    outdir = outdir or tempfile.mkdtemp(prefix="grip-soffice-")
    with tempfile.TemporaryDirectory(prefix="grip-lo-profile-") as profile:
        cmd = [
            soffice,
            f"-env:UserInstallation=file://{profile}",
            "--headless",
            "--norestore",
            "--convert-to",
            "pdf",
            "--outdir",
            outdir,
            path,
        ]
        proc = subprocess.run(cmd, capture_output=True, timeout=timeout)
    stem = os.path.splitext(os.path.basename(path))[0]
    pdf = os.path.join(outdir, stem + ".pdf")
    if not os.path.exists(pdf):
        raise RasterError(
            "LibreOffice did not produce a PDF for "
            f"{os.path.basename(path)}: {proc.stderr.decode('utf-8', 'replace')[:400]}"
        )
    return pdf


# --------------------------------------------------------------------------
# Loaders
# --------------------------------------------------------------------------


def load_pdf(
    path: str,
    dpi_scan: int,
    dpi_media: int,
    gamma: float = 1.0,
    pages: Optional[Sequence[int]] = None,
) -> List[PageRaster]:
    try:
        import pypdfium2 as pdfium
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise RasterError(
            "PDF input needs pypdfium2 (pip install 'dropspec-tools[pdf]')"
        ) from exc

    doc = pdfium.PdfDocument(path)
    wanted = list(pages) if pages else list(range(1, len(doc) + 1))
    out: List[PageRaster] = []
    render_dpi = max(dpi_scan, dpi_media)

    for number in wanted:
        if not 1 <= number <= len(doc):
            raise RasterError(f"{path} has {len(doc)} page(s); asked for {number}")
        page = doc[number - 1]
        width_mm = page.get_width() / PT_PER_INCH * MM_PER_INCH
        height_mm = page.get_height() / PT_PER_INCH * MM_PER_INCH
        bitmap = page.render(scale=render_dpi / PT_PER_INCH, grayscale=True)
        img = bitmap.to_pil()
        rows, cols = _target_shape(width_mm, height_mm, dpi_scan, dpi_media)
        if img.size != (cols, rows):
            img = img.resize((cols, rows), Image.LANCZOS)
        out.append(
            PageRaster(_to_coverage(img, gamma, invert=False), width_mm, height_mm)
        )
        page.close()
    doc.close()
    return out


def load_image(
    path: str,
    dpi_scan: int,
    dpi_media: int,
    page_size_mm: Tuple[float, float],
    gamma: float = 1.0,
    fit: str = "contain",
) -> List[PageRaster]:
    img = Image.open(path)
    width_mm, height_mm = page_size_mm
    rows, cols = _target_shape(width_mm, height_mm, dpi_scan, dpi_media)

    if fit == "stretch":
        placed = img.convert("L").resize((cols, rows), Image.LANCZOS)
    else:
        scale = min(cols / img.width, rows / img.height)
        w = max(1, int(round(img.width * scale)))
        h = max(1, int(round(img.height * scale)))
        placed = Image.new("L", (cols, rows), 255)
        placed.paste(
            img.convert("L").resize((w, h), Image.LANCZOS),
            ((cols - w) // 2, (rows - h) // 2),
        )

    return [PageRaster(_to_coverage(placed, gamma, invert=False), width_mm, height_mm)]


def load(
    path: str,
    dpi_scan: int,
    dpi_media: int,
    page_size: Optional[str] = None,
    gamma: float = 1.0,
    pages: Optional[Sequence[int]] = None,
    fit: str = "contain",
) -> List[PageRaster]:
    """Load any supported input as a list of `PageRaster`."""
    if not os.path.exists(path):
        raise RasterError(f"{path}: no such file")
    suffix = os.path.splitext(path)[1].lower()

    if suffix in IMAGE_SUFFIXES:
        size = parse_page_size(page_size or "letter")
        return load_image(path, dpi_scan, dpi_media, size, gamma, fit)

    if suffix != ".pdf":
        path = convert_to_pdf(path)

    rasters = load_pdf(path, dpi_scan, dpi_media, gamma, pages)
    if page_size:
        # An explicit page size overrides the MediaBox: the media is what is
        # actually in the machine, not what the document thought it was.
        width_mm, height_mm = parse_page_size(page_size)
        rows, cols = _target_shape(width_mm, height_mm, dpi_scan, dpi_media)
        fixed = []
        for r in rasters:
            canvas = np.zeros((rows, cols), dtype=np.float32)
            h = min(rows, r.rows)
            w = min(cols, r.columns)
            canvas[:h, :w] = r.coverage[:h, :w]
            fixed.append(PageRaster(canvas, width_mm, height_mm))
        rasters = fixed
    return rasters
