"""The RIP: continuous-tone pages in, a `.grip` container out.

Three jobs, in order:

1. **Screen** — continuous tone becomes a 1-bit mask (`halftone`)
2. **Band-split** — the page mask is divided among the pens of the gang,
   with the stitch overlap feathered between neighbours
3. **Plan** — the media-axis walk becomes passes, each pass becomes one
   `passes.csv` row and one `.ppp` per pen

Only mono banded mode is planned here.  CMYK is not a harder RIP so much as
a different pass schedule (the media walks every band under every pen in
turn) tangled with band assignment and dead-nozzle substitution, which is
deliverable F3 — it is refused loudly rather than approximated.
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from . import halftone
from .container import GripWriter
from .gcode import GcodeOptions
from .model import (
    DIR_XNEG,
    DIR_XPOS,
    GripError,
    GripOverflowError,
    MAX_PAGES,
    MAX_PASSES_PER_PAGE,
    Manifest,
    PassRow,
    Swath,
    dots_to_mm,
    mm_to_dots,
)
from .profile import MODE_MONO, MachineProfile
from .raster import PageRaster


@dataclass
class RipOptions:
    job_name: str = "untitled"
    halftone: str = "floyd-steinberg"
    threshold_level: float = 0.5
    bayer_order: int = 3
    bidirectional: bool = True
    feather: bool = True
    compresslevel: int = 6
    generator_version: str = "0.1.0"
    gcode: Optional[GcodeOptions] = None


# --------------------------------------------------------------------------
# Band assignment
# --------------------------------------------------------------------------


def _dither_field(rows: int, cols: int, order: int = 3) -> np.ndarray:
    """A deterministic ordered field in [0, 1) for feathering decisions.

    Deterministic matters: two RIPs given the same page must produce the same
    container, or the format's redundancy checks start reporting differences
    that are not faults.
    """
    m = halftone._bayer_matrix(order)
    return np.tile(
        m, (rows // m.shape[0] + 1, cols // m.shape[1] + 1)
    )[:rows, :cols]


def band_owner_map(profile: MachineProfile, columns: int, feather: bool = True) -> np.ndarray:
    """`(gang_rows, columns)` uint8: which pen owns each cell of the gang.

    Outside overlap zones this is a plain horizontal band split.  Inside an
    overlap zone the two neighbouring pens share the rows, with a linear ramp
    dithered by an ordered field — so a stitch line becomes a gradient
    between two pens instead of a hard butt joint, and a dead nozzle in the
    zone has a live neighbour covering the same row.
    """
    gang_rows = profile.gang_rows
    owner = np.zeros((gang_rows, columns), dtype=np.uint8)

    for pen in range(profile.pens):
        top = profile.pen_top_row(pen)
        owner[top : top + profile.nozzles_per_pen, :] = pen

    if profile.overlap_nozzles and feather:
        field = _dither_field(gang_rows, columns)
        for pen in range(profile.pens - 1):
            start = profile.pen_top_row(pen + 1)
            stop = start + profile.overlap_nozzles
            local = (np.arange(profile.overlap_nozzles) + 0.5) / profile.overlap_nozzles
            share_lower = local[:, None]  # fraction handed to pen+1
            zone = field[start:stop, :]
            owner[start:stop, :] = np.where(zone < share_lower, pen + 1, pen).astype(
                np.uint8
            )
    return owner


# --------------------------------------------------------------------------
# Pass planning
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class PlannedPass:
    page: int
    index: int
    start_row: int  # first gang row's index in the page raster
    dir: str
    origin_x: float
    origin_y: float


def plan_page(
    profile: MachineProfile,
    page: int,
    page_rows: int,
    page_height_mm: float,
    lead_mm: float,
    bidirectional: bool = True,
) -> List[PlannedPass]:
    if profile.mode != MODE_MONO:
        raise NotImplementedError(
            f"pass planning for mode {profile.mode!r} is deliverable F3; "
            "only mono banded mode is implemented"
        )
    if not 1 <= page <= MAX_PAGES:
        raise GripOverflowError(
            f"page {page} exceeds the frozen 3-digit field (max {MAX_PAGES}). "
            "Fields never widen: split the job."
        )

    advance = profile.advance_rows
    gang = profile.gang_rows
    count = max(1, -(-page_rows // advance))  # ceil
    if count > MAX_PASSES_PER_PAGE:
        raise GripOverflowError(
            f"page {page} needs {count} passes, exceeding the frozen 3-digit "
            f"field (max {MAX_PASSES_PER_PAGE}). Fields never widen."
        )

    pitch = profile.nozzle_pitch_mm
    out: List[PlannedPass] = []
    for k in range(count):
        start = k * advance
        direction = DIR_XPOS if (not bidirectional or k % 2 == 0) else DIR_XNEG
        out.append(
            PlannedPass(
                page=page,
                index=k + 1,
                start_row=start,
                dir=direction,
                origin_x=round(-lead_mm, 4),
                origin_y=round(page_height_mm - (start + gang) * pitch, 4),
            )
        )
    return out


# --------------------------------------------------------------------------
# Swath construction
# --------------------------------------------------------------------------


def build_swaths(
    profile: MachineProfile,
    planned: PlannedPass,
    page_bits: np.ndarray,
    owner: np.ndarray,
    lead_cols: int,
) -> List[Swath]:
    """One `.ppp` per pen for a single pass."""
    gang_rows = profile.gang_rows
    page_rows, page_cols = page_bits.shape
    columns = page_cols + 2 * lead_cols

    start = planned.start_row
    stop = min(page_rows, start + gang_rows)
    gang = np.zeros((gang_rows, page_cols), dtype=bool)
    if stop > start:
        gang[: stop - start, :] = page_bits[start:stop, :]

    swaths: List[Swath] = []
    for pen in range(profile.pens):
        top = profile.pen_top_row(pen)
        rows = slice(top, top + profile.nozzles_per_pen)
        pen_bits = gang[rows, :] & (owner[rows, :] == pen)

        # File space: line index is the fire event, character index is the
        # nozzle.  The page is inset by the clear lead-in columns.
        buf = np.zeros((columns, profile.nozzles_per_pen), dtype=bool)
        buf[lead_cols : lead_cols + page_cols, :] = pen_bits.T

        # The renderer's one conditional, applied here in reverse: on XNEG,
        # line 0 is the swath's far end.
        if planned.dir == DIR_XNEG:
            buf = buf[::-1]

        swaths.append(
            Swath(
                page=planned.page,
                index=planned.index,
                pen=pen,
                rows=profile.nozzles_per_pen,
                columns=columns,
                dir=planned.dir,
                bits=buf,
            )
        )
    return swaths


# --------------------------------------------------------------------------
# Top level
# --------------------------------------------------------------------------


def rip(
    rasters: Sequence[PageRaster],
    profile: MachineProfile,
    out_path: str,
    options: Optional[RipOptions] = None,
) -> Manifest:
    """Rip pages into `out_path` and return the manifest that was written."""
    opt = options or RipOptions()
    if not rasters:
        raise GripError("no pages to rip")

    width_mm = rasters[0].width_mm
    height_mm = rasters[0].height_mm
    for r in rasters[1:]:
        if abs(r.width_mm - width_mm) > 0.01 or abs(r.height_mm - height_mm) > 0.01:
            raise GripError(
                "mixed page sizes in one job: manifest.ini carries a single "
                "media extent. Split the job or force a page size."
            )

    manifest = profile.manifest(width_mm, height_mm)
    manifest.job_name = opt.job_name
    manifest.created = _dt.datetime.now(_dt.timezone.utc).replace(
        microsecond=0
    ).isoformat().replace("+00:00", "Z")
    manifest.halftone = opt.halftone
    manifest.generator_version = opt.generator_version

    lead_cols = int(round(mm_to_dots(profile.lead_mm, profile.dpi_scan)))
    droplets: Dict[int, int] = {p: 0 for p in range(profile.pens)}

    writer = GripWriter(out_path, compresslevel=opt.compresslevel)
    try:
        owner: Optional[np.ndarray] = None
        for page_number, raster in enumerate(rasters, start=1):
            bits = halftone.screen(
                raster.coverage,
                opt.halftone,
                level=opt.threshold_level,
                bayer_order=opt.bayer_order,
            )
            if owner is None or owner.shape[1] != bits.shape[1]:
                owner = band_owner_map(profile, bits.shape[1], opt.feather)

            for planned in plan_page(
                profile,
                page_number,
                bits.shape[0],
                raster.height_mm,
                profile.lead_mm,
                opt.bidirectional,
            ):
                swaths = build_swaths(profile, planned, bits, owner, lead_cols)
                for sw in swaths:
                    droplets[sw.pen] += int(np.count_nonzero(sw.bits))
                writer.add_pass(
                    PassRow(
                        page=planned.page,
                        index=planned.index,
                        origin_x=planned.origin_x,
                        origin_y=planned.origin_y,
                        dir=planned.dir,
                    ),
                    swaths,
                )

        for spec in manifest.pen_specs:
            spec.planned_droplets = droplets.get(spec.index, 0)
            # pL -> mL is 1e-9.  The arithmetic is left auditable on purpose:
            # drop_volume_pl is the assumption, not a measurement.
            spec.planned_consumption = round(
                spec.planned_droplets * spec.drop_volume_pl * 1e-9, 12
            )

        manifest.pages = len(rasters)
        writer.close(manifest, gcode_options=opt.gcode)
    except BaseException:
        writer.__exit__(GripError, GripError("rip failed"), None)
        raise
    return manifest
