"""`command.gcode` — the motion plan, Klipper-consumable.

**T is the control plane.  Q is the data plane.**

Toolchange (`T00`-`T99`) arms the RIP: it names the pen and is already
understood by Klipper, senders and log readers.  `Qxnn` moves swaths into
the firing buffers, `nn` being the pen and the digit being urgency,
descending:

* `Q1nn` — load into the go buffer.  **Blocking.**  Legal anywhere, but
  expected only at cold start and after a fault: blocking at parse time
  stalls the lookahead queue, which is correct at cold start and wrong
  mid-job.
* `Q2nn` — stage.  Async: fires the transfer and returns immediately.
* `Q3nn` — verify that promotion occurred, and make it true if it did not.
  **Blocking, at print time, at a pass boundary** — where a stall costs a
  pause between sweeps rather than a starved move.  A missing `Q2nn` is
  treated as a failed promotion, not a no-op.
* `Q4nn` — discard both buffers for that pen.  The defined way to reach a
  known-empty state; the correct call on job dump and fault-stop.

Steady state runs `Q3` then `Q2` and never touches `Q1` again.

Scheduling caveat, the one thing in the design that fails *silently*:
Klipper's gcode processing runs ahead of motion, so `Q3nn` must be scheduled
against the toolhead's print time, not executed at parse time.  That is a
firmware obligation of the `[tij_printhead]` module (deliverable E2); this
emitter only guarantees that `Q3nn` appears at the pass boundary where that
scheduling is meaningful.
"""

from __future__ import annotations

import io
from typing import Dict, List, Optional, Sequence, Tuple

from .model import DIR_XPOS, Manifest, PassRow, swath_filename


class GcodeOptions:
    def __init__(
        self,
        print_speed_mm_s: float = 625.0,
        travel_speed_mm_s: float = 800.0,
        advance_speed_mm_s: float = 100.0,
        start_macro: Optional[str] = "PRESS_JOB_START",
        end_macro: Optional[str] = "PRESS_JOB_END",
        page_eject_macro: Optional[str] = "PRESS_SHEET_EJECT",
        page_load_macro: Optional[str] = "PRESS_SHEET_LOAD",
    ) -> None:
        self.print_speed_mm_s = print_speed_mm_s
        self.travel_speed_mm_s = travel_speed_mm_s
        self.advance_speed_mm_s = advance_speed_mm_s
        self.start_macro = start_macro
        self.end_macro = end_macro
        self.page_eject_macro = page_eject_macro
        self.page_load_macro = page_load_macro

    def f(self, mm_s: float) -> int:
        return int(round(mm_s * 60.0))


def _sweep_extent(
    manifest: Manifest, row: PassRow, columns: int
) -> Tuple[float, float]:
    """(start_x, end_x) of the commanded move, in machine millimetres.

    The swath spans the full commanded move, leading and trailing columns
    clear.  Array sized by geometry, nothing computed at runtime, no case
    where the pass ends early with data still in the buffer.
    """
    width = columns * 25.4 / manifest.dpi_scan
    low, high = row.origin_x, row.origin_x + width
    return (low, high) if row.dir == DIR_XPOS else (high, low)


def emit(
    manifest: Manifest,
    rows: Sequence[PassRow],
    columns_by_key: Dict[Tuple[int, int], int],
    options: Optional[GcodeOptions] = None,
) -> str:
    opt = options or GcodeOptions()
    pens = list(range(manifest.pens))
    out = io.StringIO()
    w = out.write

    w(f"; DROPSpec .grip command.gcode\n")
    w(f"; job: {manifest.job_name}\n")
    w(f"; generated: {manifest.created} by {manifest.generator} "
      f"{manifest.generator_version}\n")
    w(f"; container version {manifest.version}, profile {manifest.profile}\n")
    w(f"; {manifest.pages} page(s), {manifest.passes_total} pass(es), "
      f"{manifest.pens} pen(s)\n")
    w("; T is the control plane. Q is the data plane.\n")
    w(";\n")
    w("; Q3nn MUST be scheduled against toolhead print time, not parse time.\n")
    w("; A parse-time Q3 runs before the pass it verifies and asserts nothing.\n")
    w("\n")

    if opt.start_macro:
        w(f"{opt.start_macro}\n")
    w("G90\n")
    w("\n")

    order: List[PassRow] = sorted(rows, key=lambda r: (r.page, r.index))
    if not order:
        if opt.end_macro:
            w(f"{opt.end_macro}\n")
        return out.getvalue()

    def files(row: PassRow) -> List[str]:
        return [swath_filename(row.page, row.index, p) for p in pens]

    # -- cold start: fill the go buffer synchronously, then arm ------------
    first = order[0]
    w(f"; ---- page {first.page} ----\n")
    if opt.page_load_macro:
        w(f"{opt.page_load_macro}\n")
    w("; cold start: Q1 blocks until the go buffer is real\n")
    for pen, name in zip(pens, files(first)):
        w(f"Q1{pen:02d} FILE={name}\n")
    w("; toolchange arms the RIP and names the pen\n")
    for pen in pens:
        w(f"T{pen:02d}\n")
    w("\n")

    for i, row in enumerate(order):
        nxt = order[i + 1] if i + 1 < len(order) else None

        if nxt is not None:
            w(f"; stage pass {nxt.page}/{nxt.index}\n")
            for pen, name in zip(pens, files(nxt)):
                w(f"Q2{pen:02d} FILE={name}\n")

        cols = columns_by_key[(row.page, row.index)]
        start_x, end_x = _sweep_extent(manifest, row, cols)
        w(
            f"; pass {row.page}/{row.index} {row.dir} "
            f"origin ({row.origin_x:.4g}, {row.origin_y:.4g}) mm, "
            f"{cols} columns\n"
        )
        w(f"G1 X{start_x:.4f} F{opt.f(opt.travel_speed_mm_s)}\n")
        w(f"G1 X{end_x:.4f} F{opt.f(opt.print_speed_mm_s)}\n")

        if nxt is None:
            break

        if nxt.page != row.page:
            w("\n")
            if opt.page_eject_macro:
                w(f"{opt.page_eject_macro}\n")
            w(f"; ---- page {nxt.page} ----\n")
            if opt.page_load_macro:
                w(f"{opt.page_load_macro}\n")
        else:
            advance = row.origin_y - nxt.origin_y
            if abs(advance) > 1e-9:
                w(f"; media advance {advance:.4f} mm\n")
                w("G91\n")
                w(f"G1 Y{advance:.4f} F{opt.f(opt.advance_speed_mm_s)}\n")
                w("G90\n")

        w("; verify promotion of the staged pass; blocking, at print time\n")
        for pen in pens:
            w(f"Q3{pen:02d}\n")
        w("\n")

    w("\n; ---- end of job ----\n")
    if opt.page_eject_macro:
        w(f"{opt.page_eject_macro}\n")
    w("; discard: a machine that stops with stale swaths can resume into garbage\n")
    for pen in pens:
        w(f"Q4{pen:02d}\n")
    if opt.end_macro:
        w(f"{opt.end_macro}\n")

    return out.getvalue()
