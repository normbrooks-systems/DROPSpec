"""Screening: continuous-tone coverage becomes a 1-bit mask.

This is DROPSpec deliverable F2 in its baseline form.  Error diffusion is the
default because it is the honest baseline for a binary press with no drop
modulation; ordered dithers are here because they are reproducible by hand
and make good fixtures.

Depletion masking — thinning the mask in high-coverage regions so the pen's
thermal duty and the substrate's fluid load stay survivable — is *not*
implemented.  It is real work and it needs bench numbers, so it is a stub
with a name rather than a guess with a number.

Everything here takes and returns arrays in page-raster orientation:
`(media_rows, scan_columns)`, row 0 at the top of the page.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
from PIL import Image

METHODS = ("floyd-steinberg", "bayer", "threshold", "none")


def _bayer_matrix(order: int) -> np.ndarray:
    m = np.array([[0.0]], dtype=np.float64)
    for _ in range(order):
        m = np.block([
            [4 * m + 0, 4 * m + 2],
            [4 * m + 3, 4 * m + 1],
        ])
    return (m + 0.5) / m.size


def threshold(coverage: np.ndarray, level: float = 0.5) -> np.ndarray:
    return coverage >= level


def bayer(coverage: np.ndarray, order: int = 3) -> np.ndarray:
    m = _bayer_matrix(order)
    rows, cols = coverage.shape
    tiled = np.tile(m, (rows // m.shape[0] + 1, cols // m.shape[1] + 1))[:rows, :cols]
    return coverage > tiled


def floyd_steinberg(coverage: np.ndarray) -> np.ndarray:
    """Error diffusion, via Pillow's C implementation.

    Pillow dithers luminance, so coverage is inverted on the way in and the
    result inverted back: an ink dot is a black pixel is a set bit.
    """
    lum = np.clip((1.0 - coverage) * 255.0 + 0.5, 0, 255).astype(np.uint8)
    img = Image.fromarray(lum, mode="L").convert("1", dither=Image.FLOYDSTEINBERG)
    return np.asarray(img, dtype=bool) == False  # noqa: E712 - black means ink


def screen(
    coverage: np.ndarray,
    method: str = "floyd-steinberg",
    level: float = 0.5,
    bayer_order: int = 3,
) -> np.ndarray:
    """Dispatch.  Returns a boolean array: True is a fired nozzle."""
    method = method.lower()
    if method in ("floyd-steinberg", "fs", "error-diffusion"):
        return floyd_steinberg(coverage)
    if method == "bayer":
        return bayer(coverage, bayer_order)
    if method == "threshold":
        return threshold(coverage, level)
    if method == "none":
        return coverage > 0.5
    raise ValueError(f"unknown halftone method {method!r}; expected one of {METHODS}")


def depletion_mask(
    bits: np.ndarray, limit: Optional[float] = None
) -> np.ndarray:  # pragma: no cover - deliberately unimplemented
    """Thin the mask where coverage exceeds the press's fluid/thermal limit.

    Not implemented.  The limit is a measured property of ink, media and
    firing energy; picking a number here would be inventing bench data.
    Recorded as a named hole so it is not mistaken for something the RIP
    already does.
    """
    raise NotImplementedError(
        "depletion masking needs bench numbers (deliverable F2); "
        "no default is honest"
    )
