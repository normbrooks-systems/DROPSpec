"""The `.grip` archive itself.

A zip archive with four members, each with an obvious owner:

* `manifest.ini`  — what this job is.  Constant size, whatever the job length
* `passes.csv`    — where each pass lands.  Grows with the job
* `command.gcode` — the motion plan, Klipper-consumable
* `rip/`          — the swaths, in print order

Deflate, zip64 where required, `rip/` as a path prefix with no directory
entries: directory entries are omitted by enough writers that requiring them
only creates false negatives in validation.

Member write order is swaths first, metadata last.  A zip is indexed by its
central directory, so order is not semantic — and writing this way lets the
RIP stream a 500-page job without holding its rasters in memory.
"""

from __future__ import annotations

import os
import zipfile
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from . import gcode as gcode_mod
from . import manifest_io, passes_io, ppp
from .model import (
    GripFormatError,
    Manifest,
    PassRow,
    Swath,
    parse_swath_filename,
)

MANIFEST_NAME = "manifest.ini"
PASSES_NAME = "passes.csv"
GCODE_NAME = "command.gcode"
RIP_PREFIX = "rip/"


class GripWriter:
    """Streaming writer.  Feed it swaths, then close it with a manifest."""

    def __init__(self, path: str, compresslevel: int = 6) -> None:
        self.path = path
        self._zf = zipfile.ZipFile(
            path,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            allowZip64=True,
            compresslevel=compresslevel,
        )
        self.rows: List[PassRow] = []
        self.columns_by_key: Dict[Tuple[int, int], int] = {}
        self._written: set = set()

    def add_pass(self, row: PassRow, swaths: Sequence[Swath]) -> None:
        row.validate()
        if row.key in self._written:
            raise GripFormatError(
                f"pass (page {row.page}, pass {row.index}) added twice"
            )
        if not swaths:
            raise GripFormatError(f"pass {row.key} has no swaths")

        cols = {s.columns for s in swaths}
        if len(cols) != 1:
            raise GripFormatError(
                f"pass {row.key}: pens disagree on COLUMNS {sorted(cols)}; "
                "all pens in a pass share one sweep"
            )

        for sw in swaths:
            if (sw.page, sw.index) != row.key:
                raise GripFormatError(
                    f"swath {sw.filename} does not belong to pass {row.key}"
                )
            if sw.dir != row.dir:
                raise GripFormatError(
                    f"{sw.filename}: DIR:{sw.dir} disagrees with passes.csv "
                    f"{row.dir}; passes.csv is authoritative"
                )
            self._zf.writestr(RIP_PREFIX + sw.filename, ppp.dumps(sw))

        self.rows.append(row)
        self.columns_by_key[row.key] = cols.pop()
        self._written.add(row.key)

    def close(
        self,
        manifest: Manifest,
        gcode_options: Optional["gcode_mod.GcodeOptions"] = None,
        gcode_text: Optional[str] = None,
    ) -> None:
        manifest.passes_total = len(self.rows)
        manifest.pages = len({r.page for r in self.rows}) or manifest.pages

        if gcode_text is None:
            gcode_text = gcode_mod.emit(
                manifest, self.rows, self.columns_by_key, gcode_options
            )

        self._zf.writestr(MANIFEST_NAME, manifest_io.dumps(manifest))
        self._zf.writestr(PASSES_NAME, passes_io.dumps(self.rows))
        self._zf.writestr(GCODE_NAME, gcode_text)
        self._zf.close()

    def __enter__(self) -> "GripWriter":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if exc_type is not None:
            self._zf.close()
            try:
                os.unlink(self.path)
            except OSError:
                pass


class GripReader:
    """Random-access reader.  Swaths are decoded on demand, never all at once."""

    def __init__(self, path: str) -> None:
        self.path = path
        try:
            self._zf = zipfile.ZipFile(path, "r")
        except zipfile.BadZipFile as exc:
            raise GripFormatError(f"{path} is not a zip archive") from exc

        names = set(self._zf.namelist())
        for required in (MANIFEST_NAME, PASSES_NAME):
            if required not in names:
                raise GripFormatError(f"{path}: missing {required}")

        self.manifest = manifest_io.loads(self._read_text(MANIFEST_NAME))
        self.rows = passes_io.loads(self._read_text(PASSES_NAME))
        self.has_gcode = GCODE_NAME in names

        self.swath_names: List[str] = sorted(
            n
            for n in names
            if n.startswith(RIP_PREFIX) and n.endswith(".ppp") and not n.endswith("/")
        )

    # -- members -----------------------------------------------------------

    def _read_text(self, name: str) -> str:
        return self._zf.read(name).decode("utf-8")

    @property
    def gcode(self) -> str:
        return self._read_text(GCODE_NAME) if self.has_gcode else ""

    def swath(self, page: int, index: int, pen: int) -> Swath:
        from .model import swath_filename

        name = RIP_PREFIX + swath_filename(page, index, pen)
        try:
            data = self._zf.read(name)
        except KeyError as exc:
            raise GripFormatError(f"{self.path}: missing member {name}") from exc
        return ppp.loads(data, name)

    def swath_by_name(self, name: str) -> Swath:
        return ppp.loads(self._zf.read(name), name)

    def iter_swaths(self) -> Iterable[Tuple[str, Swath]]:
        for name in self.swath_names:
            yield name, self.swath_by_name(name)

    def swath_index(self) -> Dict[Tuple[int, int], List[int]]:
        """`(page, pass) -> [pen, ...]`, from filenames alone."""
        index: Dict[Tuple[int, int], List[int]] = {}
        for name in self.swath_names:
            page, idx, pen = parse_swath_filename(name)
            index.setdefault((page, idx), []).append(pen)
        for pens in index.values():
            pens.sort()
        return index

    def row(self, page: int, index: int) -> PassRow:
        for r in self.rows:
            if r.key == (page, index):
                return r
        raise GripFormatError(f"passes.csv has no (page {page}, pass {index})")

    @property
    def pages(self) -> List[int]:
        return sorted({r.page for r in self.rows})

    def rows_for_page(self, page: int) -> List[PassRow]:
        return sorted((r for r in self.rows if r.page == page), key=lambda r: r.index)

    def close(self) -> None:
        self._zf.close()

    def __enter__(self) -> "GripReader":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
