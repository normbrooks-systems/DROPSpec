"""Machine profiles — the geometry a RIP needs and the container records.

A profile is *not* part of the container.  It is the description of the press
the job is being ripped for; the container carries only the consequences.
Keeping it separate is what lets `params/machine.scad` and this file
eventually be generated from one source without either owning the other.

The reference profile is DDP-01: four HP 45 class (TIJ 2.5) pens, 300 nozzles
each at 600 npi — a half inch of array per pen — staggered along the media
axis so the gang spans ~2 inches.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Sequence

from .model import MM_PER_INCH, Manifest, PenSpec, dots_to_mm

MODE_MONO = "mono"
MODE_CMYK = "cmyk"


@dataclass
class MachineProfile:
    """Everything the RIP needs to know about the press.

    `overlap_nozzles` is DROPSpec open decision O3.  Non-zero is recommended:
    it buys stitch feathering and dead-nozzle substitution room, at the cost
    of `overlap_nozzles` rows of gang span per pen boundary.
    """

    name: str = "DDP-01"
    pens: int = 4
    nozzles_per_pen: int = 300
    dpi_media: int = 600
    dpi_scan: int = 600
    overlap_nozzles: int = 8
    mode: str = MODE_MONO
    colorants: Sequence[str] = field(default_factory=lambda: ["black"] * 4)
    srgb_hints: Sequence[str] = field(default_factory=list)
    drop_volume_pl: float = 30.0

    #: Millimetres of clear lead-in and lead-out on the scan axis.  The swath
    #: spans the full commanded move, so these become clear columns rather
    #: than a shorter array — nothing is computed at runtime.
    lead_mm: float = 3.0

    #: Nominal scan-axis offsets between pens (staircase arrangement, O2).
    #: Inline four is all-zero.  Recorded per pen, in millimetres.
    pen_offsets_x: Sequence[float] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.pens < 1:
            raise ValueError("a profile needs at least one pen")
        if not 0 <= self.overlap_nozzles < self.nozzles_per_pen:
            raise ValueError("overlap_nozzles must be in 0..nozzles_per_pen-1")
        if len(self.colorants) != self.pens:
            raise ValueError(
                f"profile declares {self.pens} pens but "
                f"{len(self.colorants)} colorants"
            )

    # -- media-axis geometry ------------------------------------------------

    @property
    def nozzle_pitch_mm(self) -> float:
        return MM_PER_INCH / self.dpi_media

    @property
    def pen_array_rows(self) -> int:
        return self.nozzles_per_pen

    @property
    def pen_pitch_rows(self) -> int:
        """Media-axis stagger between adjacent pens, in nozzle rows."""
        return self.nozzles_per_pen - self.overlap_nozzles

    @property
    def gang_rows(self) -> int:
        """Total media-axis extent of the gang in nozzle rows."""
        return (self.pens - 1) * self.pen_pitch_rows + self.nozzles_per_pen

    @property
    def gang_height_mm(self) -> float:
        return dots_to_mm(self.gang_rows, self.dpi_media)

    @property
    def advance_rows(self) -> int:
        """Media advance between passes, in nozzle rows.

        Mono: the whole gang lays a stitched band per pass, so the advance is
        the gang span.  CMYK: the media must walk every band under every pen
        in turn, so the advance is one pen pitch.
        """
        return self.gang_rows if self.mode == MODE_MONO else self.pen_pitch_rows

    def pen_top_row(self, pen: int) -> int:
        """Row index of pen `pen`'s character-0 nozzle within the gang.

        Row 0 is the AA-most (top) row of the gang; index increases downward,
        i.e. in decreasing y — the same sense as a `.ppp` character index.
        """
        return pen * self.pen_pitch_rows

    def pen_offset_y_mm(self, pen: int) -> float:
        """Page-space +y offset of pen `pen`'s band bottom from the swath origin."""
        rows_below = self.gang_rows - self.pen_top_row(pen) - self.nozzles_per_pen
        return dots_to_mm(rows_below, self.dpi_media)

    def pen_offset_x_mm(self, pen: int) -> float:
        if pen < len(self.pen_offsets_x):
            return float(self.pen_offsets_x[pen])
        return 0.0

    # -- manifest projection ------------------------------------------------

    def pen_specs(self) -> List[PenSpec]:
        hints = list(self.srgb_hints) + [None] * self.pens
        return [
            PenSpec(
                index=i,
                colorant=self.colorants[i],
                srgb=hints[i],
                offset_x=round(self.pen_offset_x_mm(i), 4),
                offset_y=round(self.pen_offset_y_mm(i), 4),
                drop_volume_pl=self.drop_volume_pl,
            )
            for i in range(self.pens)
        ]

    def manifest(self, page_width_mm: float, page_height_mm: float) -> Manifest:
        return Manifest(
            pens=self.pens,
            nozzles_per_pen=self.nozzles_per_pen,
            dpi_scan=self.dpi_scan,
            dpi_media=self.dpi_media,
            page_width=round(page_width_mm, 4),
            page_height=round(page_height_mm, 4),
            pen_specs=self.pen_specs(),
            overlap_nozzles=self.overlap_nozzles,
        )


#: The reference implementation, mono: four black pens, 8-nozzle stitch overlap.
DDP01_MONO = MachineProfile()

#: The reference implementation, CMYK: colour lay-down order is fixed by the
#: aluminium, not the firmware — slot order is the print order.
DDP01_CMYK = MachineProfile(
    mode=MODE_CMYK,
    colorants=["cyan", "magenta", "yellow", "black"],
    srgb_hints=["#009EE0", "#E6008C", "#FFE600", "#000000"],
)

#: One pen on a bench rig.  The single-pen case is first-class (A1.1).
BENCH_SINGLE = MachineProfile(
    name="bench-1", pens=1, overlap_nozzles=0, colorants=["black"]
)

PROFILES = {
    "ddp01-mono": DDP01_MONO,
    "ddp01-cmyk": DDP01_CMYK,
    "bench-1": BENCH_SINGLE,
}
