"""`manifest.ini` — read and write.

Lowercase keys with underscores, `version` first.  Constant size, whatever
the job length: everything that scales with job length lives in `passes.csv`.
"""

from __future__ import annotations

import configparser
import io
from typing import List

from .model import (
    GRIP_VERSION,
    GripFormatError,
    Manifest,
    PROFILE_SHEET,
    PenSpec,
)


def _fmt(value: float) -> str:
    """Enough significant figures to survive a round trip, always a float.

    `planned_consumption` for a light page is microlitres, so a fixed number
    of decimal places would quietly round the provenance to zero.
    """
    text = f"{value:.9g}"
    if "." not in text and "e" not in text and "E" not in text:
        text += ".0"
    return text


def dumps(m: Manifest) -> str:
    out = io.StringIO()
    w = out.write

    w("[grip]\n")
    w(f"version = {m.version}\n")
    w(f"profile = {m.profile}\n")
    w(f"job_name = {m.job_name}\n")
    w(f"created = {m.created}\n")
    w(f"pages = {m.pages}\n")
    w(f"passes_total = {m.passes_total}\n")
    w(f"pens = {m.pens}\n")

    w("\n[geometry]\n")
    w(f"nozzles_per_pen = {m.nozzles_per_pen}\n")
    w(f"dpi_scan = {m.dpi_scan}\n")
    w(f"dpi_media = {m.dpi_media}\n")
    w(f"page_width = {_fmt(m.page_width)}\n")
    w(f"page_height = {_fmt(m.page_height)}\n")

    for pen in sorted(m.pen_specs, key=lambda p: p.index):
        w(f"\n[{pen.section}]\n")
        w(f"colorant = {pen.colorant}\n")
        if pen.srgb:
            w(f"srgb = {pen.srgb}\n")
        w(f"offset_x = {_fmt(pen.offset_x)}\n")
        w(f"offset_y = {_fmt(pen.offset_y)}\n")
        w(f"planned_droplets = {pen.planned_droplets}\n")
        w(f"planned_consumption = {_fmt(pen.planned_consumption)}\n")
        w(f"drop_volume_pl = {_fmt(pen.drop_volume_pl)}\n")

    # Informative.  Consumers SHALL NOT alter behaviour based on anything here.
    w("\n[rip]\n")
    w(f"generator = {m.generator}\n")
    w(f"generator_version = {m.generator_version}\n")
    w(f"halftone = {m.halftone}\n")
    w(f"overlap_nozzles = {m.overlap_nozzles}\n")
    w(f"interleave = {m.interleave}\n")

    return out.getvalue()


def loads(text: str) -> Manifest:
    cp = configparser.ConfigParser()
    cp.optionxform = str  # keys are already lowercase; do not mangle them
    try:
        cp.read_string(text)
    except configparser.Error as exc:
        raise GripFormatError(f"manifest.ini does not parse: {exc}") from exc

    for required in ("grip", "geometry"):
        if not cp.has_section(required):
            raise GripFormatError(f"manifest.ini has no [{required}] section")

    g = cp["grip"]
    geo = cp["geometry"]

    pens: List[PenSpec] = []
    try:
        pens = _pen_specs(cp)
    except ValueError as exc:
        raise GripFormatError(f"manifest.ini has a malformed value: {exc}") from exc

    rip = cp["rip"] if cp.has_section("rip") else {}

    def rget(key, default):
        try:
            return rip.get(key, default)  # type: ignore[union-attr]
        except AttributeError:
            return default

    try:
        return _build(g, geo, rip, pens, rget)
    except ValueError as exc:
        raise GripFormatError(f"manifest.ini has a malformed value: {exc}") from exc


def _pen_specs(cp) -> List[PenSpec]:
    pens: List[PenSpec] = []
    for name in cp.sections():
        if not name.startswith("pen."):
            continue
        s = cp[name]
        try:
            index = int(name.split(".", 1)[1])
        except ValueError as exc:
            raise GripFormatError(f"[{name}] is not [pen.nn]") from exc
        pens.append(
            PenSpec(
                index=index,
                colorant=s.get("colorant", "black"),
                srgb=s.get("srgb") or None,
                offset_x=s.getfloat("offset_x", 0.0),
                offset_y=s.getfloat("offset_y", 0.0),
                planned_droplets=s.getint("planned_droplets", 0),
                planned_consumption=s.getfloat("planned_consumption", 0.0),
                drop_volume_pl=s.getfloat("drop_volume_pl", 30.0),
            )
        )
    pens.sort(key=lambda p: p.index)
    return pens


def _build(g, geo, rip, pens, rget) -> Manifest:
    return Manifest(
        version=g.get("version", GRIP_VERSION),
        profile=g.get("profile", PROFILE_SHEET),
        job_name=g.get("job_name", "untitled"),
        created=g.get("created", ""),
        pages=g.getint("pages", 0),
        passes_total=g.getint("passes_total", 0),
        pens=g.getint("pens", len(pens)),
        nozzles_per_pen=geo.getint("nozzles_per_pen", 300),
        dpi_scan=geo.getint("dpi_scan", 600),
        dpi_media=geo.getint("dpi_media", 600),
        page_width=geo.getfloat("page_width", 0.0),
        page_height=geo.getfloat("page_height", 0.0),
        pen_specs=pens,
        generator=rget("generator", ""),
        generator_version=rget("generator_version", ""),
        halftone=rget("halftone", ""),
        overlap_nozzles=int(rget("overlap_nozzles", 0) or 0),
        interleave=int(rget("interleave", 1) or 1),
    )
