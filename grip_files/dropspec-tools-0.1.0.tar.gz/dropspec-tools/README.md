# dropspec-tools

Reference tooling for the DROPSpec `.grip` job container: a RIP, a renderer,
and a validator.

```
grip-write   report.odt -o report.grip      # document  -> container
grip-validate report.grip                   # the seven checks
grip-render  report.grip -o proof.pdf       # container -> proof
grip-info    report.grip --passes           # what's in there
```

Status: **v0.1, mono banded mode.** Written against `grip_format_notes.md`
(container draft 0.3). Nothing here is frozen; see `docs/spec-findings.md`
for the places where implementing the notes required deciding something the
notes leave open.

## Install

```
pip install -e .[pdf,test]
```

`numpy` and `pillow` are required. `pypdfium2` is needed for PDF input.
LibreOffice, if present on `PATH`, is used to convert anything else.

## What it does

**`grip-write`** takes a document — PDF, PNG, or anything LibreOffice opens —
and produces a `.grip`:

1. **Rasterise** the page to continuous-tone ink coverage at the press's
   `dpi_scan` × `dpi_media`
2. **Screen** it to 1 bit (Floyd–Steinberg by default; ordered and threshold
   available for fixtures)
3. **Band-split** the page across the pens of the gang, feathering the stitch
   overlap with a dithered linear ramp so a band boundary is a gradient rather
   than a butt joint
4. **Plan** the media walk into passes, alternating `XPOS` / `XNEG`
5. **Emit** `manifest.ini`, `passes.csv`, `command.gcode` and one `.ppp` per
   pen per pass, streamed into the archive so job length does not become
   memory

**`grip-render`** goes the other way and produces a proof. The PDF output is
one `ImageMask` per pen composited with a `Multiply` blend — no flattening to
RGB — so overlapping inks darken the way ink does. If the proof looks right,
the file is right, before a drop of ink.

The proof consumes `[pen.nn] colorant` and `srgb`, which are informative, to
pick fill colours. **A PDF whose colours look wrong is not a spec violation.**
What the proof establishes is geometry.

**`grip-validate`** runs the seven checks in the order they fail usefully,
plus two the notes imply but do not list (all pens in a pass agree on
`COLUMNS`; `planned_droplets` matches the rasters — the second as a warning,
since `[pen.nn]` is provenance). Failures in swath bodies report a line
number.

## The geometry, in one place

The reference press is four HP 45 class pens, 300 nozzles each at 600 npi —
a half inch of array per pen — staggered along the media axis. With an
8-nozzle stitch overlap:

```
pen pitch     292 rows   12.361 mm
gang span    1176 rows   49.784 mm      <- the swath, and the per-pass advance
US Letter    6600 rows  279.400 mm      -> 6 passes, the last overhanging
```

Page space is bottom-left origin, +x along scan, +y along media advance, all
millimetres — the same coordinate system as `printer.cfg`, on purpose.

File space inside a `.ppp` disagrees in two places, both deliberately: line 0
is the first column *fired*, so on `XNEG` it runs high-x to low-x; character 0
is the nozzle nearest **AA**, so it runs in *decreasing* y.

**The renderer's full conditional logic is: reverse line order on `XNEG`.**
Everything else is unconditional. `dropspec/render.py` has exactly one `if`
that depends on `dir`, and that is the invariant worth protecting in review.

## Layout

```
src/dropspec/
  model.py        dataclasses, field widths, filename grammar, placement
  profile.py      MachineProfile — the press, not the container
  manifest_io.py  manifest.ini
  passes_io.py    passes.csv
  ppp.py          .ppp read/write, with line numbers on failure
  gcode.py        command.gcode — the T/Q arming protocol
  container.py    the zip: GripWriter (streaming), GripReader (lazy)
  raster.py       PDF / image / LibreOffice input
  halftone.py     screening (F2 baseline)
  rip.py          band split, pass planning, the top-level rip()
  render.py       proofs: PNG, and a small hand-rolled ImageMask PDF writer
  validate.py     the checks
  cli/            grip-write, grip-render, grip-validate, grip-info
docs/
  spec-findings.md         what implementing the notes turned up
  cups-and-libreoffice.md  F1 design note, and the path that works today
examples/
  libreoffice/ExportGrip.bas   "Export as .grip" macro
  testpattern.py               calibration fixtures, written via the API
tests/                       58 tests, including mutation tests on the validator
```

## Not implemented, on purpose

- **CMYK pass planning.** The media walks every band under every pen in turn;
  tangled with band assignment and dead-nozzle substitution, which is
  deliverable F3. `plan_page` raises `NotImplementedError` rather than
  approximating it.
- **Depletion masking.** Needs bench numbers. `halftone.depletion_mask`
  raises rather than inventing a limit.
- **`profile = roll`.** Enumerated and reserved. A v1 reader refuses it, and
  so does this one — check 1, before anything else.
- **The CUPS filter.** See `docs/cups-and-libreoffice.md` for why the option
  vocabulary should not be frozen before O2/O3/O6 close.

## Tests

```
python -m pytest
```

The validator tests are mutation tests: they take a good container, break
exactly one thing, and assert that the validator names *that* thing. That is
the property worth having — a validator that says "invalid" is not much more
useful than a machine that refuses to print.

## Licence

GPLv3, matching the DROPSpec software licence.
